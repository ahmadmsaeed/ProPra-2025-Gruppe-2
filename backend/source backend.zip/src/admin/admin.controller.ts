import { Controller, Get, Patch, Param, Body, UseGuards, ParseIntPipe, ForbiddenException, Req } from '@nestjs/common';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard'; // Assuming RolesGuard exists
import { Roles } from '../auth/roles.decorator'; // Assuming Roles decorator exists
import { Role } from '@prisma/client';

@Controller('admin')
@UseGuards(JwtAuthGuard, RolesGuard) // Protect all routes
@Roles(Role.ADMIN) // Allow only ADMIN role
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  @Get('merchants')
  async listMerchants() {
    return this.adminService.listMerchants();
  }

  @Get('customers')
  async listCustomersWithOrders() {
    return this.adminService.listCustomersWithOrders();
  }

  @Patch('users/:id/block')
  async blockUser(
    @Param('id', ParseIntPipe) userId: number,
    @Req() req,
  ) {
    if (req.user.sub === userId) {
      throw new ForbiddenException('Admin cannot block themselves.');
    }
    return this.adminService.blockUser(userId);
  }

  @Patch('users/:id/unblock')
  async unblockUser(@Param('id', ParseIntPipe) userId: number) {
    return this.adminService.unblockUser(userId);
  }
}
