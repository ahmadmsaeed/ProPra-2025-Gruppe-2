import { Module } from '@nestjs/common';
import { OrdersController } from './orders.controller';
import { OrdersService } from './orders.service';
import { PrismaModule } from '../prisma/prisma.module'; // Corrected path
import { PdfModule } from '../pdf/pdf.module'; // Corrected path
import { AuthModule } from '../auth/auth.module'; // Corrected path
import { BlockedUserGuard } from '../auth/blocked-user.guard'; // Corrected path
import { PrismaService } from '../prisma/prisma.service'; // Corrected path
// Remove MerchantOrdersController if not used or merged
// import { MerchantOrdersController } from './merchant-orders.controller';

@Module({
  imports: [PrismaModule, PdfModule, AuthModule], // Add PdfModule and AuthModule
  controllers: [OrdersController /*, MerchantOrdersController */],
  providers: [OrdersService, BlockedUserGuard, PrismaService], // Provide BlockedUserGuard and its dependency PrismaService
})
export class OrdersModule {}
