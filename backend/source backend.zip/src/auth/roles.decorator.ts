import { SetMetadata } from '@nestjs/common';

export const ROLES_KEY = 'roles';
export type RoleType = 'CUSTOMER' | 'MERCHANT' | 'ADMIN';
export const Roles = (...roles: RoleType[]) => SetMetadata(ROLES_KEY, roles);
