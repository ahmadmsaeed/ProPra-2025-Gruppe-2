import { Controller, Post, Body, HttpException, HttpStatus, Request, UseGuards, Get, Req, Query, Optional, Patch, Param, ParseIntPipe, Res, ForbiddenException, NotFoundException } from '@nestjs/common';
import { AuthService } from './auth.service';
import { JwtAuthGuard } from './jwt-auth.guard';
import { RolesGuard } from './roles.guard';
import { Roles } from './roles.decorator';
import { Role, OrderStatus } from '@prisma/client';
import { Response } from 'express';
import { PdfService } from '../pdf/pdf.service';
import { BlockedUserGuard } from './blocked-user.guard';

/**
 * Controller für Authentifizierungs-Endpunkte: Registrierung, Login, Profil.
 */
@Controller('auth')
export class AuthController {
  constructor(
      private readonly authService: AuthService,
      private pdfService: PdfService,
    ) {}

  /**
   * Registrierung eines neuen Users.
   */
  @Post('register')
  async register(@Body() dto: { email: string; password: string; name: string }) {
    return this.authService.register(dto);
  }

  /**
   * Login eines Users. Gibt bei Erfolg ein JWT zurück.
   */
  @Post('login')
  async login(@Body() dto: { email: string; password: string }) {
    return this.authService.login(dto);
  }

  /**
   * Gibt die eigenen Userdaten zurück (nur mit gültigem JWT).
   */
  @UseGuards(JwtAuthGuard, BlockedUserGuard)
  @Get('me')
  @UseGuards(JwtAuthGuard, BlockedUserGuard)
  @Get('me')
  async me(@Req() req) {
    return this.authService.me(req.user);
  }

  /**
   * Gibt die Statistiken des Händlers zurück (nur für Händler, mit gültigem JWT).
   */
  @UseGuards(JwtAuthGuard, RolesGuard, BlockedUserGuard)
  @Roles(Role.MERCHANT)
  @Get('merchant/stats')
  async getMerchantStats(@Req() req) {
    return this.authService.getMerchantStats(req.user.sub);
  }

  /**
   * Gibt die Bestellungen des Händlers zurück (nur für Händler, mit gültigem JWT).
   */
  @UseGuards(JwtAuthGuard, RolesGuard, BlockedUserGuard)
  @Roles(Role.MERCHANT)
  @Get('merchant/orders')
  async getMerchantOrders(
    @Req() req,
    @Query('date') @Optional() date?: string,
  ) {
    return this.authService.getMerchantOrdersByDate(req.user.sub, date);
  }

  /**
   * Lädt das Versandetikett als PDF herunter (nur für Händler, mit gültigem JWT).
   */
  @UseGuards(JwtAuthGuard, RolesGuard, BlockedUserGuard)
  @Roles(Role.MERCHANT)
  @Get('merchant/orders/:id/shipping-label')
  async downloadShippingLabel(
    @Param('id', ParseIntPipe) orderId: number,
    @Req() req,
    @Res() res: Response,
  ) {
    const merchantId = req.user.sub;
    const order = await this.authService.getMerchantOrderById(merchantId, orderId);

    if (!order) {
      throw new NotFoundException(`Order with ID ${orderId} not found or does not belong to this merchant.`);
    }

    const pdfBuffer = await this.pdfService.generateShippingLabelPdf(order as any);

    res.set({
      'Content-Type': 'application/pdf',
      'Content-Disposition': `attachment; filename=label-${order.orderNumber}.pdf`,
      'Content-Length': pdfBuffer.length,
    });
    res.end(pdfBuffer);
  }

  /**
   * Aktualisiert den Status einer Bestellung (nur für Händler, mit gültigem JWT).
   */
  @UseGuards(JwtAuthGuard, RolesGuard, BlockedUserGuard)
  @Roles(Role.MERCHANT)
  @Patch('merchant/orders/:id/status')
  async updateOrderStatus(
      @Param('id', ParseIntPipe) orderId: number,
      @Body('status') status: OrderStatus,
      @Req() req,
  ) {
      const merchantId = req.user.sub;
      // Validate status value
      if (!Object.values(OrderStatus).includes(status)) {
          throw new ForbiddenException(`Invalid status value: ${status}`);
      }
      return this.authService.updateMerchantOrderStatus(merchantId, orderId, status);
  }
}
