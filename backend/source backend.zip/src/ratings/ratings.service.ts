import { Injectable, HttpException, HttpStatus } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';

/**
 * Service für Bewertungen (Ratings).
 */
@Injectable()
export class RatingsService {
  constructor(private prisma: PrismaService) {}

  /**
   * Gibt alle Bewertungen zu einem Buch zurück (inkl. User-Name).
   */
  async getRatingsForBook(bookId: number) {
    return this.prisma.rating.findMany({
      where: { bookId },
      include: { user: { select: { id: true, name: true } } },
      orderBy: { createdAt: 'desc' },
    });
  }

  /**
   * Gibt eine Bewertung für ein Buch ab oder aktualisiert sie (pro User nur eine Bewertung pro Buch).
   */
  async rateBook(userId: number, bookId: number, value: number) {
    // Upsert: Wenn Bewertung existiert, aktualisieren, sonst neu anlegen
    return this.prisma.rating.upsert({
      where: { userId_bookId: { userId, bookId } },
      update: { value },
      create: { userId, bookId, value },
    });
  }
}
