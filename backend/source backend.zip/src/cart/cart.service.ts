import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';

@Injectable()
export class CartService {
  constructor(private prisma: PrismaService) {}

  async getCart(userId: number) {
    return this.prisma.cart.findUnique({
      where: { userId },
      include: { items: { include: { book: true } } },
    });
  }

  async addToCart(userId: number, bookId: number, quantity: number) {
    // Find or create cart
    let cart = await this.prisma.cart.findUnique({ where: { userId } });
    if (!cart) {
      cart = await this.prisma.cart.create({ data: { userId } });
    }
    // Find or create cart item
    let item = await this.prisma.cartItem.findUnique({ where: { cartId_bookId: { cartId: cart.id, bookId } } });
    if (item) {
      item = await this.prisma.cartItem.update({
        where: { id: item.id },
        data: { quantity: item.quantity + quantity },
      });
    } else {
      item = await this.prisma.cartItem.create({
        data: { cartId: cart.id, bookId, quantity },
      });
    }
    return item;
  }

  async removeFromCart(userId: number, bookId: number) {
    const cart = await this.prisma.cart.findUnique({ where: { userId } });
    if (!cart) return null;
    return this.prisma.cartItem.deleteMany({ where: { cartId: cart.id, bookId } });
  }

  async clearCart(userId: number) {
    const cart = await this.prisma.cart.findUnique({ where: { userId } });
    if (!cart) return null;
    return this.prisma.cartItem.deleteMany({ where: { cartId: cart.id } });
  }
}
