// src/articles/books.service.ts

import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';

@Injectable()
export class BooksService {
  constructor(private prisma: PrismaService) {}

  findAll() {
    return this.prisma.book.findMany({ where: { published: true } });
  }

  async findOne(id: number) {
    const book = await this.prisma.book.findUnique({ where: { id } });
    if (!book) {
        throw new NotFoundException(`Book with ID ${id} not found`);
    }
    return book;
  }

  async findShop(shopId: number) {
    return this.prisma.shop.findUnique({ where: { id: shopId } });
  }

  async createBook(shopId: number, dto: { title: string; subtitle?: string; published?: boolean }) {
    return this.prisma.book.create({
      data: {
        title: dto.title,
        subtitle: dto.subtitle,
        published: dto.published ?? false,
        shopId,
      },
    });
  }

  async updateBook(merchantId: number, bookId: number, dto: { title?: string; subtitle?: string; published?: boolean }) {
    return this.prisma.book.update({
      where: { id: bookId },
      data: dto,
    });
  }

  async deleteBook(merchantId: number, bookId: number) {
    return this.prisma.book.delete({ where: { id: bookId } });
  }

  async searchBooks(query: string) {
    return this.prisma.book.findMany({
      where: {
        published: true,
        OR: [
          { title: { contains: query, mode: 'insensitive' } },
          { subtitle: { contains: query, mode: 'insensitive' } },
        ],
      },
      include: {
          shop: { select: { name: true } }
      }
    });
  }
}