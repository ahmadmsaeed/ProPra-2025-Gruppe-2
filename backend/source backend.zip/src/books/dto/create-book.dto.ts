import { IsString, IsNotEmpty, IsOptional, IsISBN, IsNumber, IsPositive, IsDateString } from 'class-validator';

export class CreateBookDto {
  @IsString()
  @IsNotEmpty()
  title: string;

  @IsString()
  @IsOptional()
  subtitle?: string;

  @IsISBN()
  @IsNotEmpty()
  isbn: string;

  @IsString()
  @IsOptional()
  description?: string;

  @IsNumber()
  @IsPositive()
  price: number;

  @IsDateString()
  @IsOptional()
  published?: string; // Or Date, depending on how you handle it

  // shopId will be added by the service based on the route/auth user
}
