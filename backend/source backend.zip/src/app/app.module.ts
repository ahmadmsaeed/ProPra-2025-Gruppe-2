import { Module } from '@nestjs/common';
import { AppController } from '../app.controller';
import { AppService } from '../app.service';
import { AdminModule } from '../admin/admin.module';
import { PrismaModule } from '../prisma/prisma.module';
import { AuthModule } from '../auth/auth.module';
import { ShopsModule } from '../shops/shops.module';
import { BooksModule } from '../books/books.module';
import { RatingsModule } from '../ratings/ratings.module';
import { CartModule } from '../cart/cart.module';
import { OrdersModule } from '../orders/orders.module';
import { PdfModule } from '../pdf/pdf.module';


@Module({
  imports: [
    PrismaModule,
    AuthModule,
    ShopsModule,
    BooksModule,
    RatingsModule,
    CartModule,
    OrdersModule,
    AdminModule, // Add AdminModule here
    PdfModule, // Add PdfModule here
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
