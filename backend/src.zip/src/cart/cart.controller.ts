import { Controller, Get, Post, Delete, Body, UseGuards, Request } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { CartService } from './cart.service';

@Controller('cart')
@UseGuards(JwtAuthGuard)
export class CartController {
  constructor(private readonly cartService: CartService) {}

  @Get()
  getCart(@Request() req) {
    return this.cartService.getCart(req.user.sub);
  }

  @Post('add')
  addToCart(@Request() req, @Body() dto: { bookId: number; quantity: number }) {
    return this.cartService.addToCart(req.user.sub, dto.bookId, dto.quantity);
  }

  @Post('remove')
  removeFromCart(@Request() req, @Body() dto: { bookId: number }) {
    return this.cartService.removeFromCart(req.user.sub, dto.bookId);
  }

  @Delete('clear')
  clearCart(@Request() req) {
    return this.cartService.clearCart(req.user.sub);
  }
}
