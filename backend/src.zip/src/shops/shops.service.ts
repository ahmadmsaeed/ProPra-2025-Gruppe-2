import { Injectable } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';

@Injectable()
export class ShopsService {
  constructor(private prisma: PrismaService) {}

  async findAll() {
    return this.prisma.shop.findMany({
      include: {
        books: true,  // Include books for each shop
      },
    });
  }

  async findOne(id: number) {
    return this.prisma.shop.findUnique({
      where: { id },
      include: {
        books: true,
      },
    });
  }

  async findBooksByShop(shopId: number) {
    return this.prisma.book.findMany({
      where: { shopId },
      select: {
        id: true,
        title: true,
        subtitle: true,
        published: true,
        price: true, // <-- Ensure price is included
      },
    });
  }

  /**
   * Gibt alle Shops eines bestimmten Händlers zurück.
   */
  async findByOwner(ownerId: number) {
    return this.prisma.shop.findMany({
      where: { ownerId },
      include: { books: true },
    });
  }

  /**
   * Legt einen neuen Shop für einen Händler an.
   */
  async createShop(ownerId: number, dto: { name: string; location: string }) {
    return this.prisma.shop.create({
      data: {
        name: dto.name,
        location: dto.location,
        ownerId,
      },
    });
  }

  /**
   * Aktualisiert einen Shop.
   */
  async updateShop(id: number, dto: { name?: string; location?: string }) {
    return this.prisma.shop.update({
      where: { id },
      data: dto,
    });
  }

  /**
   * Löscht einen Shop.
   */
  async deleteShop(id: number) {
    // Delete all books for this shop before deleting the shop itself
    await this.prisma.book.deleteMany({ where: { shopId: id } });
    return this.prisma.shop.delete({ where: { id } });
  }

  /**
   * Dashboard: Umsatz pro Buch und pro Tag für den Händler
   */
  async getSalesStats(ownerId: number) {
    // Alle Bücher des Händlers
    const books = await this.prisma.book.findMany({
      where: { shop: { ownerId } },
      select: { id: true, title: true },
    });
    // Umsatz pro Buch
    const salesPerBook = await Promise.all(
      books.map(async (book) => {
        const items = await this.prisma.orderItem.findMany({
          where: { bookId: book.id },
          select: { quantity: true, price: true },
        });
        const revenue = items.reduce((sum, i) => sum + i.quantity * i.price, 0);
        return { bookId: book.id, title: book.title, revenue };
      })
    );
    // Umsatz pro Tag (über alle Bücher)
    const orders = await this.prisma.order.findMany({
      where: {
        items: { some: { book: { shop: { ownerId } } } },
      },
      select: { createdAt: true, totalAmount: true },
    });
    const salesPerDay: Record<string, number> = {};
    for (const order of orders) {
      const day = order.createdAt.toISOString().slice(0, 10);
      salesPerDay[day] = (salesPerDay[day] || 0) + order.totalAmount;
    }
    return { salesPerBook, salesPerDay };
  }
}