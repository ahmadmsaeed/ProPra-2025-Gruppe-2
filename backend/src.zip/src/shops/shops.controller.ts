
import { Controller, Get, Param, UseGuards, Request, Post, Body, Patch, Delete, NotFoundException, ForbiddenException } from '@nestjs/common';
import { ShopsService } from './shops.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles } from '../auth/roles.decorator';
import { RolesGuard } from '../auth/roles.guard';

@Controller('shops')
export class ShopsController {
  constructor(private readonly shopsService: ShopsService) {}


  @Get()
  async findAll() {
    return this.shopsService.findAll();
  }

  /**
   * Gibt alle Shops des eingeloggten Händlers zurück (nur für MERCHANT).
   */
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('MERCHANT')
  @Get('mine')
  async findMyShops(@Request() req) {
    return this.shopsService.findByOwner(req.user.sub);
  }

  /**
   * Legt einen neuen Shop für den eingeloggten Händler an.
   */
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('MERCHANT')
  @Post('mine')
  async createShop(@Request() req, @Body() dto: { name: string; location: string }) {
    return this.shopsService.createShop(req.user.sub, dto);
  }

  /**
   * Bearbeitet einen eigenen Shop (nur für Besitzer).
   */
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('MERCHANT')
  @Patch('mine/:id')
  async updateShop(@Request() req, @Param('id') id: string, @Body() dto: { name?: string; location?: string }) {
    const shop = await this.shopsService.findOne(Number(id));
    if (!shop) throw new NotFoundException('Shop nicht gefunden');
    if (shop.ownerId !== req.user.sub) throw new ForbiddenException('Kein Zugriff auf diesen Shop');
    return this.shopsService.updateShop(Number(id), dto);
  }

  /**
   * Löscht einen eigenen Shop (nur für Besitzer).
   */
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('MERCHANT')
  @Delete('mine/:id')
  async deleteShop(@Request() req, @Param('id') id: string) {
    const shop = await this.shopsService.findOne(Number(id));
    if (!shop) throw new NotFoundException('Shop nicht gefunden');
    if (shop.ownerId !== req.user.sub) throw new ForbiddenException('Kein Zugriff auf diesen Shop');
    return this.shopsService.deleteShop(Number(id));
  }

  @Get(':id')
  async findOne(@Param('id') id: number) {
    return this.shopsService.findOne(id);
  }

  @Get(':id/books')
  async findBooksByShop(@Param('id') id: string) {
    return this.shopsService.findBooksByShop(Number(id));
  }
}