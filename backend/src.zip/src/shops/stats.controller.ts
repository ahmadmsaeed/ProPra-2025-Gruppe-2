import { Controller, Get, UseGuards, Request } from '@nestjs/common';
import { ShopsService } from './shops.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles } from '../auth/roles.decorator';
import { RolesGuard } from '../auth/roles.guard';

@Controller('shops/stats')
export class StatsController {
  constructor(private readonly shopsService: ShopsService) {}

  /**
   * Dashboard: Umsatz pro Buch und pro Tag für den eingeloggten Händler
   */
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles('MERCHANT')
  @Get('sales')
  async getSalesStats(@Request() req) {
    return this.shopsService.getSalesStats(req.user.sub);
  }
}
