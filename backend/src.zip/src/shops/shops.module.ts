import { Module } from '@nestjs/common';
import { PrismaModule } from '../prisma/prisma.module';  // Adjust the path as needed
import { ShopsService } from './shops.service';
import { ShopsController } from './shops.controller';

@Module({
  imports: [PrismaModule],  // Import PrismaModule here
  providers: [ShopsService],
  controllers: [ShopsController],
})
export class ShopsModule {}
