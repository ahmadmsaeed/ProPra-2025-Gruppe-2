// src/articles/books.controller.ts

import { Controller, Get, Query, Param, Post, Body, Patch, Delete, UseGuards, Request, NotFoundException, ForbiddenException } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles } from '../auth/roles.decorator';
import { RolesGuard } from '../auth/roles.guard';
import { BooksService } from './books.service';
import { Role } from '@prisma/client'; // Import Role enum

@Controller('books')
export class BooksController {
  constructor(private readonly booksService: BooksService) {}

  @Get()
  findAll() {
    return this.booksService.findAll();
  }

  @Get('search')
  async searchBooks(@Query('query') query: string) {
    if (!query || query.trim() === '') {
      return this.booksService.findAll();
    }
    // Service method name matches summary
    return this.booksService.searchBooks(query.trim());
  }

  @Get(':id')
  findOne(@Param('id') id: string) {
    return this.booksService.findOne(Number(id));
  }

  /**
   * Buch im eigenen Shop anlegen (nur für Händler, nur im eigenen Shop).
   */
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.MERCHANT) // Use Role enum
  @Post('shop/:shopId')
  async createBook(
    @Request() req,
    @Param('shopId') shopId: string,
    @Body() dto: { title: string; subtitle?: string; published?: boolean }
  ) {
    const shop = await this.booksService.findShop(Number(shopId));
    if (!shop) throw new NotFoundException('Shop nicht gefunden');
    if (shop.ownerId !== req.user.sub) throw new ForbiddenException('Kein Zugriff auf diesen Shop');
    return this.booksService.createBook(Number(shopId), dto);
  }

  /**
   * Buch im eigenen Shop bearbeiten (nur für Händler, nur im eigenen Shop).
   */
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.MERCHANT) // Use Role enum
  @Patch('shop/:shopId/book/:bookId')
  async updateBook(
    @Request() req,
    @Param('shopId') shopId: string,
    @Param('bookId') bookId: string,
    @Body() dto: { title?: string; subtitle?: string; published?: boolean }
  ) {
    const shop = await this.booksService.findShop(Number(shopId));
    if (!shop) throw new NotFoundException('Shop nicht gefunden');
    if (shop.ownerId !== req.user.sub) throw new ForbiddenException('Kein Zugriff auf diesen Shop');
    return this.booksService.updateBook(req.user.sub, Number(bookId), dto);
  }

  /**
   * Buch im eigenen Shop löschen (nur für Händler, nur im eigenen Shop).
   */
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(Role.MERCHANT) // Use Role enum
  @Delete('shop/:shopId/book/:bookId')
  async deleteBook(
    @Request() req,
    @Param('shopId') shopId: string,
    @Param('bookId') bookId: string
  ) {
    const shop = await this.booksService.findShop(Number(shopId));
    if (!shop) throw new NotFoundException('Shop nicht gefunden');
    if (shop.ownerId !== req.user.sub) throw new ForbiddenException('Kein Zugriff auf diesen Shop');
    return this.booksService.deleteBook(req.user.sub, Number(bookId));
  }
}