import { Injectable, NotFoundException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { Role } from '@prisma/client';

@Injectable()
export class AdminService {
  constructor(private prisma: PrismaService) {}

  async listMerchants() {
    // Rely on the select clause to shape the return type
    return this.prisma.user.findMany({
      where: { role: Role.MERCHANT },
      select: { // Select specific fields, excluding password
        id: true,
        email: true,
        name: true,
        createdAt: true,
        role: true,
        isBlocked: true,
      },
    });
  }

  async listCustomersWithOrders() {
    // Rely on the select clause to shape the return type
    return this.prisma.user.findMany({
      where: { role: Role.CUSTOMER },
      select: { // Select specific fields, excluding password
        id: true,
        email: true,
        name: true,
        createdAt: true,
        role: true,
        isBlocked: true,
        orders: { // Include orders with specific fields
          select: {
            id: true,
            createdAt: true,
            orderNumber: true,
            status: true,
            totalAmount: true,
          },
        },
      },
    });
  }

  async blockUser(userId: number) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException(`User with ID ${userId} not found`);
    }
    // Rely on the select clause to shape the return type
    return this.prisma.user.update({
      where: { id: userId },
      data: { isBlocked: true },
      select: { // Select specific fields, excluding password
        id: true,
        email: true,
        name: true,
        createdAt: true,
        role: true,
        isBlocked: true,
      },
    });
  }

  async unblockUser(userId: number) {
    const user = await this.prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new NotFoundException(`User with ID ${userId} not found`);
    }
    // Rely on the select clause to shape the return type
    return this.prisma.user.update({
      where: { id: userId },
      data: { isBlocked: false },
      select: { // Select specific fields, excluding password
        id: true,
        email: true,
        name: true,
        createdAt: true,
        role: true,
        isBlocked: true,
      },
    });
  }
}
