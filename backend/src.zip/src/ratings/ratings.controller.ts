import { Controller, Post, Body, UseGuards, Request, Get, Param, HttpException, HttpStatus } from '@nestjs/common';
import { RatingsService } from './ratings.service';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';

/**
 * Controller für Bewertungen (Ratings).
 */
@Controller()
export class RatingsController {
  constructor(private readonly ratingsService: RatingsService) {}

  /**
   * Gibt alle Bewertungen zu einem Buch zurück.
   */
  @Get('books/:id/ratings')
  async getRatingsForBook(@Param('id') bookId: string) {
    return this.ratingsService.getRatingsForBook(Number(bookId));
  }

  /**
   * Gibt eine Bewertung für ein Buch ab (nur für eingeloggte User).
   */
  @UseGuards(JwtAuthGuard)
  @Post('ratings')
  async rateBook(
    @Body() dto: { bookId: number; value: number },
    @Request() req
  ) {
    if (dto.value < 1 || dto.value > 5) {
      throw new HttpException('Bewertung muss zwischen 1 und 5 liegen', HttpStatus.BAD_REQUEST);
    }
    return this.ratingsService.rateBook(req.user.sub, dto.bookId, dto.value);
  }
}
