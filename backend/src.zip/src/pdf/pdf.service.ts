import { Injectable } from '@nestjs/common';
import * as PDFDocument from 'pdfkit';
import { Order, OrderItem, User, Book } from '@prisma/client';

// Type for the user data needed in PDFs (selected fields)
type PdfUserData = Pick<User, 'id' | 'name' | 'email'>;

interface EnrichedOrderItem extends OrderItem {
  book: Book; // Expect full book details
}

// Adjusted EnrichedOrder type expecting specific user fields and full item/book details
interface EnrichedOrder extends Omit<Order, 'userId'> { // Omit userId as it's not in the selected user object
  items: EnrichedOrderItem[];
  user: PdfUserData; // Expect only selected user fields
}

// Type guard to validate the structure passed to PDF methods
function isEnrichedOrder(order: any): order is EnrichedOrder {
  return (
    order &&
    typeof order === 'object' &&
    typeof order.id === 'number' && // Check essential Order fields
    typeof order.orderNumber === 'string' &&
    typeof order.totalAmount === 'number' &&
    order.createdAt instanceof Date &&
    Array.isArray(order.items) &&
    // Check each item has necessary fields and a valid book object
    order.items.every(item =>
        item &&
        typeof item === 'object' &&
        typeof item.id === 'number' &&
        typeof item.quantity === 'number' &&
        typeof item.price === 'number' &&
        item.book && // Check book exists
        typeof item.book === 'object' &&
        typeof item.book.id === 'number' &&
        typeof item.book.title === 'string' &&
        typeof item.book.price === 'number' // Check essential book fields
    ) &&
    // Check user object has the expected selected fields
    order.user &&
    typeof order.user === 'object' &&
    typeof order.user.id === 'number' &&
    typeof order.user.name === 'string' &&
    typeof order.user.email === 'string' &&
    // Ensure fields NOT selected are absent
    !order.user.hasOwnProperty('password') &&
    !order.user.hasOwnProperty('role') &&
    !order.user.hasOwnProperty('isBlocked')
  );
}


@Injectable()
export class PdfService {

  async generateInvoicePdf(orderInput: any): Promise<Buffer> {
    // Validate the input structure using the type guard
    if (!isEnrichedOrder(orderInput)) {
        console.error('Invalid order data provided to generateInvoicePdf:', JSON.stringify(orderInput, null, 2)); // Log the invalid data prettified
        throw new Error('Invalid order data structure for PDF generation (Invoice).');
    }
    // Type assertion is safe now after the guard
    const order: EnrichedOrder = orderInput;

    const pdfBuffer: Buffer = await new Promise(resolve => {
      const doc = new PDFDocument({ margin: 50, size: 'A4' });
      const buffers: Buffer[] = [];

      // --- PDF Content Generation --- 
      // Header
      doc.fontSize(20).text('Rechnung', { align: 'center' });
      doc.moveDown();

      // Order Details
      doc.fontSize(12);
      doc.text(`Bestellnummer: ${order.orderNumber}`);
      doc.text(`Datum: ${new Date(order.createdAt).toLocaleDateString('de-DE')} ${new Date(order.createdAt).toLocaleTimeString('de-DE')}`);
      doc.moveDown();

      // Customer Details (using selected fields)
      doc.text('Kunde:');
      doc.text(order.user.name);
      doc.text(order.user.email);
      doc.moveDown();

      // Shipping Address
      doc.text('Lieferadresse:');
      doc.text(order.shippingName);
      doc.text(order.shippingStreet);
      doc.text(`${order.shippingZip} ${order.shippingCity}`);
      doc.text(order.shippingCountry);
      doc.moveDown();

      // Items Table Header
      const tableTop = doc.y;
      const itemCol = 50;
      const qtyCol = 350;
      const priceCol = 400;
      const totalCol = 470;

      doc.fontSize(10).text('Artikel', itemCol, tableTop);
      doc.text('Menge', qtyCol, tableTop);
      doc.text('Einzelpreis', priceCol, tableTop, { align: 'right' }); // Changed header
      doc.text('Gesamt', totalCol, tableTop, { align: 'right' });
      doc.moveTo(itemCol, doc.y).lineTo(550, doc.y).stroke();
      doc.moveDown(0.5);

      // Items Table Rows
      order.items.forEach(item => {
        const y = doc.y;
        doc.fontSize(10).text(`${item.book.title}${item.book.subtitle ? ' - ' + item.book.subtitle : ''}`, itemCol, y, { width: qtyCol - itemCol - 10 });
        doc.text(item.quantity.toString(), qtyCol, y);
        // Use the book's price as the unit price
        const unitPrice = item.book.price;
        doc.text(unitPrice.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' }), priceCol, y, { align: 'right', width: totalCol - priceCol - 10 });
        // item.price is the total for the line item (quantity * unitPrice)
        doc.text(item.price.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' }), totalCol, y, { align: 'right' });
        doc.moveDown(0.5);
      });

      // Total
      doc.moveTo(itemCol, doc.y).lineTo(550, doc.y).stroke();
      doc.moveDown(0.5);
      doc.fontSize(12).text('Gesamtsumme:', itemCol, doc.y);
      doc.text(order.totalAmount.toLocaleString('de-DE', { style: 'currency', currency: 'EUR' }), totalCol, doc.y, { align: 'right' });

      // --- End PDF Content --- 

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        resolve(Buffer.concat(buffers));
      });
      doc.end();
    });

    return pdfBuffer;
  }

  async generateShippingLabelPdf(orderInput: any): Promise<Buffer> {
     // Validate the input structure using the type guard
    if (!isEnrichedOrder(orderInput)) {
        console.error('Invalid order data provided to generateShippingLabelPdf:', JSON.stringify(orderInput, null, 2)); // Log the invalid data prettified
        throw new Error('Invalid order data structure for PDF generation (Shipping Label).');
    }
    // Type assertion is safe now after the guard
    const order: EnrichedOrder = orderInput;

     const pdfBuffer: Buffer = await new Promise(resolve => {
      const doc = new PDFDocument({ margin: 30, size: [288, 432] }); // Approx 4x6 inches
      const buffers: Buffer[] = [];

      // --- Label Content --- 
      doc.fontSize(14).text(`Bestellnr: ${order.orderNumber}`, { align: 'right' });
      doc.moveDown(2);

      doc.fontSize(16).text('Lieferadresse:', { underline: true });
      doc.moveDown(0.5);
      doc.fontSize(12);
      doc.text(order.shippingName);
      doc.text(order.shippingStreet);
      doc.text(`${order.shippingZip} ${order.shippingCity}`);
      doc.text(order.shippingCountry);
      doc.moveDown();
      // --- End Label Content --- 

      doc.on('data', buffers.push.bind(buffers));
      doc.on('end', () => {
        resolve(Buffer.concat(buffers));
      });
      doc.end();
    });

    return pdfBuffer;
  }
}
