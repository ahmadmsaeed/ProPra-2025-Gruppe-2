import { NestFactory } from '@nestjs/core';
import { AppModule } from './app.module';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Enable CORS for requests from Angular frontend
  app.enableCors({
    origin: 'http://localhost:4200',  // Allow Angular frontend to access the API
    methods: 'GET, POST, PUT, DELETE', // Allowed methods
    allowedHeaders: 'Content-Type, Authorization', // Allowed headers
  });

  await app.listen(process.env.PORT ?? 3000);  // Ensure the API listens on the correct port
}
bootstrap();
