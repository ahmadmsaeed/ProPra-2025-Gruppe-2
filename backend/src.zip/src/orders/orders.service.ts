import { Injectable, NotFoundException, ForbiddenException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { CreateOrderDto } from './dto/create-order.dto'; // Corrected path
import { OrderStatus, Prisma } from '@prisma/client'; // Import Prisma namespace

@Injectable()
export class OrdersService {
  constructor(private prisma: PrismaService) {}

  async getOrdersForUser(userId: number) {
    return this.prisma.order.findMany({
      where: { userId },
      select: {
        id: true,
        orderNumber: true,
        createdAt: true,
        status: true, // <-- Ensure status is included
        totalAmount: true,
        shippingName: true,
        items: {
          include: {
            book: true,
          },
        },
      },
      orderBy: {
        createdAt: 'desc',
      },
    });
  }

  async getOrderByIdForUser(orderId: number, userId: number) {
    const order = await this.prisma.order.findUnique({
      where: { id: orderId },
      include: {
        items: {
          include: {
            book: true, // Include full book details for items
          },
        },
        user: { // Include only necessary user details for PDF generation
          select: {
            id: true,
            email: true,
            name: true,
            // Do not select password, createdAt, role, isBlocked etc.
          }
        },
      },
    });

    if (!order) {
      throw new NotFoundException(`Order with ID ${orderId} not found`);
    }
    // Check userId against the userId field returned by Prisma before it was omitted by select
    // Prisma still fetches userId internally to satisfy the where clause
    // Alternatively, fetch userId explicitly if needed post-query, but this check should work
    const originalOrder = await this.prisma.order.findUnique({ where: { id: orderId }, select: { userId: true } });
    if (!originalOrder || originalOrder.userId !== userId) {
         throw new ForbiddenException('Access denied');
    }

    // Return the order object with the selected user fields
    return order;
  }


  async createOrder(userId: number, createOrderDto: CreateOrderDto) {
    const { items, shippingAddress } = createOrderDto;

    let totalAmount = 0;
    // Explicitly type the array for Prisma input
    const orderItemsData: Prisma.OrderItemCreateWithoutOrderInput[] = [];

    // Use Promise.all for potentially better performance if book lookups are slow
    await Promise.all(items.map(async (item) => {
      const book = await this.prisma.book.findUnique({
        where: { id: item.bookId },
      });

      // Consolidate checks for book validity
      if (!book || !book.published || typeof book.price !== 'number' || book.price < 0) {
        // Throw specific error if book not found vs. other issues
        if (!book) throw new NotFoundException(`Book with ID ${item.bookId} not found.`);
        throw new Error(`Book with ID ${item.bookId} is unavailable or has an invalid price.`);
      }

      const itemPrice = book.price * item.quantity;
      totalAmount += itemPrice;

      // Structure matches Prisma.OrderItemCreateWithoutOrderInput
      orderItemsData.push({
        quantity: item.quantity,
        price: itemPrice, // Store total price for this line item
        book: { connect: { id: item.bookId } } // Connect to existing book
      });
    }));

     // Validate total amount after processing all items
     if (totalAmount <= 0 && orderItemsData.length > 0) {
       console.error("Order creation failed: Invalid total amount calculated.", { items, totalAmount });
       throw new Error('Calculated total amount is invalid.');
     }

    // Generate order number (consider a more robust unique ID strategy for production)
    const orderNumber = `ORD-${Date.now()}-${Math.random().toString(36).substring(2, 7).toUpperCase()}`;

    // Create the order and related items within a transaction (implicitly handled by Prisma create)
    const createdOrder = await this.prisma.order.create({
      data: {
        orderNumber,
        totalAmount,
        status: OrderStatus.PENDING, // Initial status
        // Shipping address details
        shippingName: shippingAddress.name,
        shippingStreet: shippingAddress.street,
        shippingCity: shippingAddress.city,
        shippingZip: shippingAddress.zip,
        shippingCountry: shippingAddress.country,
        // Connect to the user placing the order
        user: { connect: { id: userId } },
        // Create the related order items
        items: { create: orderItemsData },
      },
      include: {
        // Include items and their book details in the response
        items: { include: { book: true } },
      },
    });

    return createdOrder;
  }

   // Method for admins to find all orders (optional)
   async findAllOrders() {
     return this.prisma.order.findMany({
       include: {
         user: { select: { id: true, name: true, email: true } }, // Include basic user info
         items: { include: { book: { select: { id: true, title: true } } } }, // Include basic item/book info
       },
       orderBy: { createdAt: 'desc' }, // Order by creation date descending
     });
   }
}
