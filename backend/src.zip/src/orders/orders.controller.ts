import { Controller, Get, Post, Body, Param, UseGuards, Req, Res, ParseIntPipe, HttpStatus, NotFoundException, ForbiddenException } from '@nestjs/common';
import { OrdersService } from './orders.service';
import { CreateOrderDto } from './dto/create-order.dto'; // Corrected path
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { RolesGuard } from '../auth/roles.guard';
import { Roles } from '../auth/roles.decorator';
import { Role } from '@prisma/client';
import { BlockedUserGuard } from '../auth/blocked-user.guard';
import { PdfService } from '../pdf/pdf.service';
import { Response } from 'express';

@Controller('orders')
@UseGuards(JwtAuthGuard, RolesGuard, BlockedUserGuard) // Apply BlockedUserGuard here
export class OrdersController {
  constructor(
    private readonly ordersService: OrdersService,
    private readonly pdfService: PdfService, // Inject PdfService
  ) {}


  @Post()
  @Roles(Role.CUSTOMER)
  create(@Body() createOrderDto: CreateOrderDto, @Req() req) {
    // Use req.user.sub for userId (NestJS/JWT standard)
    const userId = req.user.sub;
    return this.ordersService.createOrder(userId, createOrderDto);
  }

  @Get()
  @Roles(Role.CUSTOMER)
  findAllForUser(@Req() req) {
    const userId = req.user.sub;
    return this.ordersService.getOrdersForUser(userId);
  }

  @Get(':id/invoice')
  @Roles(Role.CUSTOMER)
  async downloadInvoice(@Param('id', ParseIntPipe) id: number, @Req() req, @Res() res: Response) {
    const userId = req.user.sub;
    try {
      const order = await this.ordersService.getOrderByIdForUser(id, userId);
      if (!order) {
        // Service throws NotFound or Forbidden, but catch just in case
        return res.status(HttpStatus.NOT_FOUND).send('Order not found or access denied');
      }
      const pdfBuffer = await this.pdfService.generateInvoicePdf(order);

      res.set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `attachment; filename="invoice-${order.orderNumber}.pdf"`,
        'Content-Length': pdfBuffer.length,
      });

      res.end(pdfBuffer);
    } catch (error) {
      console.error('Error generating invoice:', error);
      if (error instanceof NotFoundException || error instanceof ForbiddenException) {
         return res.status(error.getStatus()).send(error.message);
      }
      return res.status(HttpStatus.INTERNAL_SERVER_ERROR).send('Failed to generate invoice');
    }
  }
}
