import { Controller, Get, Param, UseGuards, Request, ForbiddenException, Res } from '@nestjs/common';
import { JwtAuthGuard } from '../auth/jwt-auth.guard';
import { Roles } from '../auth/roles.decorator';
import { RolesGuard } from '../auth/roles.guard';
import { PrismaService } from '../prisma/prisma.service';
import { Response } from 'express';
import * as PDFDocument from 'pdfkit';

@Controller('merchant/orders')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles('MERCHANT')
export class MerchantOrdersController {
  constructor(private prisma: PrismaService) {}

  // Übersicht über Bestellungen für alle eigenen Shops
  @Get()
  async getOrders(@Request() req) {
    // Finde alle Shops des Händlers
    const shops = await this.prisma.shop.findMany({ where: { ownerId: req.user.sub } });
    const shopIds = shops.map(s => s.id);
    // Finde alle Bestellungen, die Bücher aus diesen Shops enthalten
    const orders = await this.prisma.order.findMany({
      where: {
        items: { some: { book: { shopId: { in: shopIds } } } },
      },
      select: {
        id: true,
        orderNumber: true,
        createdAt: true,
        status: true, // <-- Ensure status is included
        totalAmount: true,
        shippingName: true,
        user: {
          select: {
            name: true // Select only the fields you need
          }
        },
        items: {
          include: {
            book: {
              select: { title: true } // Select only needed book fields
            }
          }
        },
      },
      orderBy: { createdAt: 'desc' },
    });
    // Log the orders array just before returning to confirm status presence
    console.log('Backend: Orders being returned:', JSON.stringify(orders, null, 2));
    // Optional: Status-Filter (offen, bearbeitet)
    return { orders };
  }

  // Versandlabel als PDF generieren
  @Get(':orderId/shipping-label')
  async getShippingLabel(@Request() req, @Param('orderId') orderId: string, @Res() res: Response) {
    // Prüfen, ob Bestellung zu einem eigenen Shop gehört
    const order = await this.prisma.order.findUnique({
      where: { id: Number(orderId) },
      include: { items: { include: { book: { include: { shop: true } } } }, user: true },
    });
    if (!order) throw new ForbiddenException('Bestellung nicht gefunden');
    const isOwn = order.items.some(item => item.book.shop.ownerId === req.user.sub);
    if (!isOwn) throw new ForbiddenException('Kein Zugriff auf diese Bestellung');
    // PDF generieren
    const doc = new PDFDocument();
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `inline; filename="shipping-label-${order.orderNumber}.pdf"`);
    doc.text('Versandlabel', { align: 'center', underline: true });
    doc.moveDown();
    doc.text(`Bestellnummer: ${order.orderNumber}`);
    doc.text(`Empfänger: ${order.shippingName}`);
    doc.text(`${order.shippingStreet}`);
    doc.text(`${order.shippingZip} ${order.shippingCity}`);
    doc.text(`${order.shippingCountry}`);
    doc.end();
    doc.pipe(res);
  }
}
