import { Injectable, HttpException, HttpStatus, NotFoundException, ForbiddenException, UnauthorizedException } from '@nestjs/common';
import { PrismaService } from '../prisma/prisma.service';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { Prisma, OrderStatus, User } from '@prisma/client';

/**
 * Service für Authentifizierung und User-Management.
 */
@Injectable()
export class AuthService {
  constructor(private prisma: PrismaService, private jwt: JwtService) {}

  /**
   * Registriert einen neuen User mit gehashtem Passwort.
   */
  async register(dto: { email: string; password: string; name: string }) {
    const existing = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (existing) {
      throw new HttpException('E-Mail bereits vergeben', HttpStatus.BAD_REQUEST);
    }
    const hash = await bcrypt.hash(dto.password, 10);
    const user = await this.prisma.user.create({
      data: { email: dto.email, password: hash, name: dto.name },
    });
    return { id: user.id, email: user.email, name: user.name };
  }

  /**
   * Login: Validiert User und gibt ein JWT zurück.
   */
  async login(dto: { email: string; password: string }) {
    const user = await this.prisma.user.findUnique({ where: { email: dto.email } });
    if (!user) {
      throw new UnauthorizedException('Invalid credentials');
    }

    // Check if user is blocked BEFORE checking password
    if (user.isBlocked) {
        throw new ForbiddenException('Your account is blocked. Please contact support.');
    }

    const isPasswordValid = await bcrypt.compare(dto.password, user.password);
    if (!isPasswordValid) {
      throw new UnauthorizedException('Invalid credentials');
    }

    const payload = { email: user.email, sub: user.id, role: user.role };
    return {
      access_token: this.jwt.sign(payload),
      user: { id: user.id, name: user.name, email: user.email, role: user.role }, // Return basic user info
    };
  }

  /**
   * Gibt die Userdaten für den eingeloggten User zurück.
   */
  async me(user: { sub: number; email: string; role: string }) {
    // User is already authenticated by JwtAuthGuard and checked by BlockedUserGuard
    // We can fetch fresh data if needed, but guards already did the checks.
    const dbUser = await this.prisma.user.findUnique({ where: { id: user.sub }, select: { id: true, email: true, name: true, role: true, isBlocked: true } });
    if (!dbUser) throw new NotFoundException('User not found'); // Should not happen if JWT is valid
    // No need to check isBlocked again here, guard does it.
    return dbUser;
  }
  /**
   * Gibt Verkaufsstatistiken für einen Händler zurück.
   * Umsatz pro Buch und pro Tag.
   */
  async getMerchantStats(merchantId: number) {
    // Umsatz pro Buch
    const salesPerBook = await this.prisma.orderItem.groupBy({
      by: ['bookId'],
      where: {
        book: { shop: { ownerId: merchantId } },
      },
      _sum: { price: true, quantity: true }, // Note: Summing price might be incorrect if it's unit price
      _count: { id: true },
    });

    const allBooks = await this.prisma.book.findMany({
      where: { shop: { ownerId: merchantId } },
      select: { id: true, title: true, subtitle: true },
    });

    // Recalculate revenue per book more accurately
    const bookRevenueMap = new Map<number, { revenue: number; quantity: number }>();
    const orderItems = await this.prisma.orderItem.findMany({
        where: {
            book: { shop: { ownerId: merchantId } }
        },
        select: { bookId: true, price: true, quantity: true }
    });

    for (const item of orderItems) {
        const current = bookRevenueMap.get(item.bookId) || { revenue: 0, quantity: 0 };
        // Assuming item.price is the total price for the quantity in this item line
        current.revenue += item.price; // Or item.price * item.quantity if price is unit price
        current.quantity += item.quantity;
        bookRevenueMap.set(item.bookId, current);
    }

    const enrichedSalesPerBook = allBooks.map((book) => {
      const stats = bookRevenueMap.get(book.id);
      return {
        bookId: book.id,
        title: book.title,
        subtitle: book.subtitle || '',
        revenue: stats?.revenue || 0,
        quantity: stats?.quantity || 0,
      };
    });

    // Umsatz pro Tag - Corrected Logic
    // Fetch relevant order items first
    const relevantOrderItems = await this.prisma.orderItem.findMany({
      where: {
        book: { shop: { ownerId: merchantId } },
      },
      select: {
        orderId: true,
        price: true, // Assuming this is total price for the quantity
        quantity: true, // Include quantity if price is unit price
        order: {
          select: { createdAt: true }
        }
      }
    });

    // Calculate daily revenue correctly
    const salesPerDayMap = new Map<string, number>();
    for (const item of relevantOrderItems) {
      if (item.order) {
        const date = new Date(item.order.createdAt).toISOString().slice(0, 10);
        // Assuming item.price is the total price for the quantity in this item line
        const itemRevenue = item.price; // Or item.price * item.quantity if price is unit price
        salesPerDayMap.set(date, (salesPerDayMap.get(date) || 0) + itemRevenue);
      }
    }

    const formattedSalesPerDay = Array.from(salesPerDayMap.entries()).map(([date, revenue]) => ({
      date,
      revenue,
    })).sort((a, b) => a.date.localeCompare(b.date)); // Sort by date

    return {
      salesPerBook: enrichedSalesPerBook,
      salesPerDay: formattedSalesPerDay,
    };
  }

  // New method to get orders for a merchant, optionally filtered by date
  async getMerchantOrdersByDate(merchantId: number, date?: string) {
    const whereClause: Prisma.OrderWhereInput = {
      items: {
        some: {
          book: {
            shop: { ownerId: merchantId },
          },
        },
      },
    };

    if (date) {
      try {
        // Validate date string before creating Date objects
        const parsedDate = new Date(date);
        if (isNaN(parsedDate.getTime())) {
          throw new Error('Invalid date format');
        }
        const startDate = new Date(parsedDate);
        startDate.setUTCHours(0, 0, 0, 0); // Use UTC to avoid timezone issues
        const endDate = new Date(parsedDate);
        endDate.setUTCHours(23, 59, 59, 999); // Use UTC
        whereClause.createdAt = {
          gte: startDate,
          lte: endDate,
        };
      } catch (e) {
        // Handle invalid date format, maybe return an error or ignore the filter
        console.error("Invalid date provided:", date);
        // Decide on behavior: throw error, return empty, or ignore date filter
        // For now, let's ignore the date filter if invalid
      }
    }

    const orders = await this.prisma.order.findMany({
      where: whereClause,
      select: {
        id: true,
        orderNumber: true,
        createdAt: true,
        totalAmount: true, // This is the total for the whole order
        // Include items, filtered to only show merchant's items
        items: {
          where: {
             book: { shop: { ownerId: merchantId } }
          },
          select: {
            quantity: true,
            price: true, // Price for this item line
            book: {
              select: { title: true, subtitle: true }
            }
          }
        }
      },
      orderBy: {
        createdAt: 'desc',
      },
    });

    // Adjust the structure to match frontend expectations if necessary
    // Calculate merchant-specific total for each order
    const ordersWithMerchantTotal = orders.map(order => {
        const merchantTotal = order.items.reduce((sum, item) => sum + item.price, 0); // Adjust if price is unit price
        return {
            ...order,
            merchantTotalAmount: merchantTotal // Add a field for the sum relevant to the merchant
        };
    });

    return { orders: ordersWithMerchantTotal };
  }

  // Method to get a specific order for a merchant
  async getMerchantOrderById(merchantId: number, orderId: number) {
    const order = await this.prisma.order.findFirst({
      where: {
        id: orderId,
        items: {
          some: {
            book: {
              shop: { ownerId: merchantId },
            },
          },
        },
      },
      include: { // Include necessary details for the label/invoice
        user: { select: { id: true, name: true, email: true } }, // Select needed user fields
        items: {
          where: {
            book: { shop: { ownerId: merchantId } }, // Ensure only merchant's items are included
          },
          include: {
            book: true,
          },
        },
      },
    });
    // Ensure items only contain those belonging to the merchant if Prisma doesn't filter includes
    if (order) {
        order.items = order.items.filter(item => item.book.shopId === merchantId); // Double-check filtering
    }
    return order; // Returns null if not found or doesn't belong to merchant
  }

  // Method to update order status for a merchant's order
  async updateMerchantOrderStatus(merchantId: number, orderId: number, status: OrderStatus) {
     // First, verify the order exists and belongs to the merchant
     const order = await this.prisma.order.findFirst({
        where: {
            id: orderId,
            items: {
                some: {
                    book: { shop: { ownerId: merchantId } } // Check if *any* item belongs to the merchant
                }
            }
        },
        // We only need to confirm existence and ownership link
        select: { id: true, status: true } // Select current status if needed for validation
     });

     if (!order) {
         throw new NotFoundException(`Order with ID ${orderId} not found or does not belong to this merchant.`);
     }

     // Optional: Add logic to prevent certain status transitions if needed
     // e.g., if (order.status === 'SHIPPED' && status === 'PENDING') throw new ForbiddenException(...);

     // Update the order status
     return this.prisma.order.update({
        where: { id: orderId },
        data: { status },
        select: { id: true, orderNumber: true, status: true } // Return updated status
     });
  }
}