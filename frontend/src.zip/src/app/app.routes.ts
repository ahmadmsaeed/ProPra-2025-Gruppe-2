import { Routes } from '@angular/router';
import { ShopListComponent } from './shop-list.component';
import { ShopBooksComponent } from './shop-books.component';
import { RegisterComponent } from './register.component';
import { LoginComponent } from './login.component';
import { ProfileComponent } from './profile.component';
import { authGuard } from './auth.guard';
import { CartComponent } from './cart.component';
import { OrderHistoryComponent } from './order-history.component';
import { MerchantDashboardComponent } from './merchant-dashboard.component';
import { MerchantOrdersComponent } from './merchant-orders.component';
import { MerchantShopsComponent } from './merchant-shops.component';
import { AdminDashboardComponent } from './admin-dashboard.component';
import { MerchantBooksComponent } from './merchant-books.component'; // Import MerchantBooksComponent

export const routes: Routes = [
  { path: '', redirectTo: 'shops', pathMatch: 'full' },
  { path: 'shops', component: ShopListComponent },
  { path: 'shops/:id/books', component: ShopBooksComponent },
  { path: 'register', component: RegisterComponent },
  { path: 'login', component: LoginComponent },
  { path: 'profile', component: ProfileComponent, canActivate: [authGuard] },
  { path: 'cart', component: CartComponent },
  { path: 'orders', component: OrderHistoryComponent, canActivate: [authGuard] },
  { path: 'merchant/dashboard', component: MerchantDashboardComponent, canActivate: [authGuard] },
  { path: 'merchant/orders', component: MerchantOrdersComponent, canActivate: [authGuard] },
  { path: 'merchant/shops', component: MerchantShopsComponent, canActivate: [authGuard] },
  { path: 'merchant/shops/:id/books', component: MerchantBooksComponent, canActivate: [authGuard] },
  { path: 'admin/dashboard', component: AdminDashboardComponent, canActivate: [authGuard] },
];
