// angular-de-tutorial/src/app/book-data.service.ts
import { Injectable } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { Observable } from "rxjs";

export interface Book {
  title: string;
  subtitle: string;
}


@Injectable({
  providedIn: "root",
})
export class BookDataService {
  constructor(private http: HttpClient) {}

  getBooks(): Observable<Book[]> {
    console.log('BookDataService.getBooks() called');
    return this.http.get<Book[]>("http://localhost:3000/books");
  }
}