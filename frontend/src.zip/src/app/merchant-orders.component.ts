import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FormsModule } from '@angular/forms';
import { AuthService } from './auth.service';
import { Observable, of, catchError, tap, map } from 'rxjs';
// Define OrderStatus, OrderItem, and Order here instead of external model
enum OrderStatus {
  PENDING   = 'PENDING',
  SHIPPED   = 'SHIPPED',
  COMPLETED = 'COMPLETED',
  CANCELLED = 'CANCELLED'
}

interface OrderItem {
  id: number;
  quantity: number;
  price: number;
  book: { id: number; title: string };
}

interface Order {
  id: number;
  orderNumber: string;
  createdAt: string;
  status: OrderStatus;
  totalAmount: number;
  shippingName: string;
  shippingStreet?: string;
  shippingCity?: string;
  shippingZip?: string;
  shippingCountry?: string;
  items?: OrderItem[];
}

@Component({
  selector: 'app-merchant-orders',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSelectModule,
    MatFormFieldModule,
    MatSnackBarModule,
    MatTooltipModule,
    MatProgressSpinnerModule,
  ],
  templateUrl: './merchant-orders.component.html',
})
export class MerchantOrdersComponent implements OnInit {
  orders$: Observable<Order[]> = of([]);
  ordersPending: Order[] = [];
  ordersDone: Order[] = [];
  loading = true;
  error: string | null = null;

  orderStatuses = Object.values(OrderStatus);
  displayedColumns: string[] = ['orderNumber', 'createdAt', 'customer', 'totalAmount', 'status', 'actions'];

  constructor(
    private http: HttpClient,
    public authService: AuthService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    if (!this.authService.isMerchant()) {
      this.error = 'Access Denied.';
      this.loading = false;
      return;
    }
    this.loadOrders();
  }

  loadOrders(): void {
    this.loading = true;
    this.error = null;

    // Correct the URL: Remove '/auth'
    this.orders$ = this.http.get<any>('http://localhost:3000/merchant/orders').pipe(
      tap(raw => console.log('🛠 raw payload', raw)),
      map(raw => raw.orders ?? raw),
      tap(arr => console.log('🛠 unwrapped orders array', arr)),
      catchError((err: HttpErrorResponse) => {
        this.handleError('Failed to load orders', err);
        return of([] as Order[]);
      })
    );

    this.orders$.subscribe({
      next: orders => {
        console.log('🛠 statuses:', orders.map(o => o.status));
        this.ordersPending = orders.filter(o => o.status === OrderStatus.PENDING);
        this.ordersDone    = orders.filter(o =>
          o.status === OrderStatus.SHIPPED || o.status === OrderStatus.COMPLETED
        );
        console.log(
          `🛠 Filtered orders – Pending: ${this.ordersPending.length}, Done: ${this.ordersDone.length}`
        );
      },
      error: err => this.handleError('Error processing orders', err),
      complete: () => {
        this.loading = false;
        console.log('🛠 Order loading observable completed.');
      }
    });
  }

  updateStatus(orderId: number, status: OrderStatus): void {
    this.http.patch<Order>(
      `http://localhost:3000/auth/merchant/orders/${orderId}/status`,
      { status }
    ).subscribe({
      next: updated => {
        this.snackBar.open(
          `Order ${updated.orderNumber} updated to ${updated.status}.`,
          'Close',
          { duration: 3000 }
        );
        [this.ordersPending, this.ordersDone].forEach(list => {
          const idx = list.findIndex(o => o.id === updated.id);
          if (idx > -1) list[idx] = updated;
        });
      },
      error: err => this.handleError('Failed to update status', err)
    });
  }

  downloadShippingLabel(orderId: number, orderNumber: string): void {
    this.http.get(
      `http://localhost:3000/auth/merchant/orders/${orderId}/shipping-label`,
      { responseType: 'blob' }
    ).subscribe({
      next: blob => {
        const url = URL.createObjectURL(blob);
        const a   = document.createElement('a');
        a.href    = url;
        a.download = `label-${orderNumber}.pdf`;
        document.body.appendChild(a);
        a.click();
        URL.revokeObjectURL(url);
        document.body.removeChild(a);
        this.snackBar.open('Label downloaded.', 'Close', { duration: 3000 });
      },
      error: err => this.handleError('Failed to download label', err)
    });
  }

  private handleError(message: string, error: HttpErrorResponse): void {
    console.error(message, error);
    this.error = `${message}: ${error.error?.message || error.statusText || 'Unknown error'}`;
    this.snackBar.open(this.error, 'Close', { duration: 5000 });
    this.loading = false;
  }
}
