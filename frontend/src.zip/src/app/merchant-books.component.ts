import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

interface Book {
  id: number;
  title: string;
  subtitle?: string;
  published: boolean;
}

@Component({
  selector: 'app-merchant-books',
  standalone: true,
  imports: [CommonModule],
  templateUrl: './merchant-books.component.html',
})
export class MerchantBooksComponent implements OnInit {
  @Input() shopId!: number;
  books$: Observable<Book[]>;
  newBook: Partial<Book> = { title: '', subtitle: '', published: true };

  constructor(private http: HttpClient) {
    this.books$ = new Observable<Book[]>();
  }

  ngOnInit() {
    this.reload();
  }

  reload() {
    this.books$ = this.http.get<Book[]>(`http://localhost:3000/shops/${this.shopId}/books`);
  }

  addBook() {
    this.http.post(`http://localhost:3000/books/shop/${this.shopId}`, this.newBook).subscribe(() => {
      this.newBook = { title: '', subtitle: '', published: true };
      this.reload();
    });
  }

  deleteBook(bookId: number) {
    this.http.delete(`http://localhost:3000/books/${bookId}`).subscribe(() => this.reload());
  }
}
