import { Component } from '@angular/core';
import { BookDataService } from '../book-data.service';
import { Observable, of } from 'rxjs';
import { catchError, tap } from 'rxjs/operators';
import { AsyncPipe, NgIf, NgFor, JsonPipe } from '@angular/common';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-book-list',
  standalone: true,
  imports: [AsyncPipe, NgIf, NgFor, JsonPipe],
  templateUrl: './book-list.component.html',
  styleUrl: './book-list.component.scss'
})
export class BookListComponent {
  books$: Observable<any>;
  error: string | null = null;
  loading = true;
  constructor(private bookData: BookDataService) {
    this.books$ = this.bookData.getBooks().pipe(
      tap(() => { this.loading = false; }),
      catchError((err) => {
        this.error = 'Could not load books. Please make sure the backend is running.';
        this.loading = false;
        return of([]);
      })
    );
  }

  trackByTitle(index: number, book: any) {
    return book.title;
  }
}