import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'filterByStatus',
  standalone: true
})
export class FilterByStatusPipe implements PipeTransform {
  transform(orders: any[], status: string): any[] {
    if (!orders || !status) {
      return orders;
    }
    return orders.filter(order => order.status === status);
  }
}
