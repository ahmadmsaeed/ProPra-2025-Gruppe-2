import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatListModule } from '@angular/material/list';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { FormsModule } from '@angular/forms';
import { AuthService } from './auth.service';
import { Observable, catchError, of, BehaviorSubject } from 'rxjs';
import { Router } from '@angular/router'; // Import Router

interface Shop {
  id: number;
  name: string;
  location: string;
  ownerId: number;
}

@Component({
  selector: 'app-merchant-shops',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatListModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
  ],
  templateUrl: './merchant-shops.component.html',
})
export class MerchantShopsComponent implements OnInit {
  // Use BehaviorSubject to allow adding/removing items easily
  private shopsSubject = new BehaviorSubject<Shop[]>([]);
  shops$ = this.shopsSubject.asObservable();

  loading = true;
  error: string | null = null;
  showAddForm = false;
  newShop = { name: '', location: '' };
  editingShop: Shop | null = null; // Track which shop is being edited

  constructor(
    private http: HttpClient,
    public authService: AuthService,
    private snackBar: MatSnackBar,
    private router: Router // Inject Router
  ) {}

  ngOnInit(): void {
     if (this.authService.isMerchant()) {
      this.loadShops();
    } else {
      this.error = "Access Denied.";
      this.loading = false;
    }
  }

  loadShops(): void {
    this.loading = true;
    this.error = null;
    this.http.get<Shop[]>('http://localhost:3000/shops/mine').pipe(
      catchError((err: HttpErrorResponse) => {
        this.handleError('Failed to load shops', err);
        return of([]);
      })
    ).subscribe(shops => {
      this.shopsSubject.next(shops);
      this.loading = false;
    });
  }

  addShop(): void {
    if (!this.newShop.name || !this.newShop.location) {
      this.snackBar.open('Name and location are required.', 'Close', { duration: 3000 });
      return;
    }
    this.http.post<Shop>('http://localhost:3000/shops/mine', this.newShop).subscribe({
      next: (createdShop) => {
        this.snackBar.open('Shop added successfully.', 'Close', { duration: 3000 });
        // Add to local list
        const currentShops = this.shopsSubject.getValue();
        this.shopsSubject.next([...currentShops, createdShop]);
        this.newShop = { name: '', location: '' }; // Reset form
        this.showAddForm = false;
      },
      error: (err) => this.handleError('Failed to add shop', err),
    });
  }

   editShop(shop: Shop): void {
    this.editingShop = { ...shop }; // Create a copy for editing
  }

  cancelEdit(): void {
    this.editingShop = null;
  }

  updateShop(): void {
    if (!this.editingShop) return;

    const { id, name, location } = this.editingShop;
     if (!name || !location) {
      this.snackBar.open('Name and location are required.', 'Close', { duration: 3000 });
      return;
    }

    this.http.put<Shop>(`http://localhost:3000/shops/mine/${this.editingShop.id}`, this.editingShop).subscribe({
      next: (updatedShop) => {
        this.snackBar.open('Shop updated successfully.', 'Close', { duration: 3000 });
        const currentShops = this.shopsSubject.getValue();
        const index = currentShops.findIndex(s => s.id === updatedShop.id);
        if (index > -1) {
          currentShops[index] = updatedShop;
          this.shopsSubject.next([...currentShops]);
        }
        this.editingShop = null; // Exit edit mode
      },
      error: (err) => this.handleError('Failed to update shop', err),
    });
  }


  deleteShop(shopId: number): void {
    if (!confirm('Are you sure you want to delete this shop? This cannot be undone.')) {
      return;
    }
    this.http.delete(`http://localhost:3000/shops/mine/${shopId}`).subscribe({
      next: () => {
        this.snackBar.open('Shop deleted successfully.', 'Close', { duration: 3000 });
        // Remove from local list
        const currentShops = this.shopsSubject.getValue();
        this.shopsSubject.next(currentShops.filter(s => s.id !== shopId));
      },
      error: (err) => this.handleError('Failed to delete shop', err),
    });
  }

  // Basic book management placeholder - needs more detail
  manageBooks(shopId: number): void {
    this.router.navigate(['/merchant/shops', shopId, 'books']);
  }


  private handleError(message: string, error: HttpErrorResponse): void {
    console.error(message, error);
    this.error = `${message}: ${error.error?.message || error.statusText}`;
    this.snackBar.open(this.error, 'Close', { duration: 5000 });
    // Consider keeping loading=true if it's a load error? Or set based on context.
    // this.loading = false;
  }
}
