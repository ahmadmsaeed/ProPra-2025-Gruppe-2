import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AuthService } from './auth.service';
import { Observable, catchError, of } from 'rxjs';

// Use Order interface similar to merchant-orders, adjust if needed
interface OrderItem {
  id: number;
  quantity: number;
  price: number;
  book: {
    id: number;
    title: string;
  };
}

interface Order {
  id: number;
  orderNumber: string;
  createdAt: string;
  status: string; // Keep as string from Prisma enum
  totalAmount: number;
  items: OrderItem[];
  // Add shipping details if needed
}

@Component({
  selector: 'app-order-history',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule,
    MatListModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
  ],
  templateUrl: './order-history.component.html',
})
export class OrderHistoryComponent implements OnInit {
  orders$: Observable<Order[]> = of([]);
  loading = true;
  error: string | null = null;

  constructor(
    private http: HttpClient,
    public authService: AuthService,
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
     if (this.authService.isCustomer()) { // Or just isLoggedIn if backend handles roles
      this.loadOrders();
    } else {
      this.error = "Access Denied or not logged in.";
      this.loading = false;
    }
  }

  loadOrders(): void {
    this.loading = true;
    this.error = null;
    this.orders$ = this.http.get<Order[]>('http://localhost:3000/orders').pipe(
      catchError((err: HttpErrorResponse) => {
        this.handleError('Failed to load order history', err);
        return of([]);
      }),
      // tap(() => this.loading = false) // Handled in subscribe
    );
    this.orders$.subscribe(() => this.loading = false);
  }

  downloadInvoice(orderId: number, orderNumber: string): void {
    this.http.get(`http://localhost:3000/orders/${orderId}/invoice`, { responseType: 'blob' }).subscribe({
      next: (blob) => {
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `invoice-${orderNumber}.pdf`;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        document.body.removeChild(a);
        this.snackBar.open('Invoice downloaded.', 'Close', { duration: 3000 });
      },
      error: (err) => this.handleError('Failed to download invoice', err),
    });
  }

  private handleError(message: string, error: HttpErrorResponse): void {
    console.error(message, error);
    this.error = `${message}: ${error.error?.message || error.statusText}`;
    this.snackBar.open(this.error, 'Close', { duration: 5000 });
    this.loading = false;
  }
}
