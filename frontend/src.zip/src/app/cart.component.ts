import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './auth.service'; // Needed for logged-in check potentially
import { Observable, BehaviorSubject, catchError, of, map, switchMap, tap } from 'rxjs';

interface CartItem {
  id: number;
  quantity: number;
  bookId: number;
  book: {
    id: number;
    title: string;
    price: number; // Assuming price is on book
  };
}

interface Cart {
  id: number;
  userId: number;
  items: CartItem[];
}

interface ShippingAddress {
  name: string;
  street: string;
  city: string;
  zip: string;
  country: string;
}

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatListModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
  ],
  templateUrl: './cart.component.html',
})
export class CartComponent implements OnInit {
  private cartSubject = new BehaviorSubject<Cart | null>(null);
  cart$ = this.cartSubject.asObservable();
  totalAmount$: Observable<number> = of(0);

  loading = true;
  error: string | null = null;
  showCheckoutForm = false;
  shippingAddress: ShippingAddress = { name: '', street: '', city: '', zip: '', country: '' };
  isPlacingOrder = false;

  constructor(
    private http: HttpClient,
    private snackBar: MatSnackBar,
    private router: Router,
    public authService: AuthService // Check if user is logged in
  ) {}

  ngOnInit(): void {
    this.loadCart();
    this.totalAmount$ = this.cart$.pipe(
      map(cart => cart?.items.reduce((sum, item) => sum + (item.book.price * item.quantity), 0) ?? 0)
    );
  }

  loadCart(): void {
    this.loading = true;
    this.error = null;
    this.http.get<Cart>('http://localhost:3000/cart').pipe(
      catchError((err: HttpErrorResponse) => {
        // Handle 404 specifically if cart doesn't exist yet for user
        if (err.status === 404) {
          return of(null); // Treat as empty cart
        }
        this.handleError('Failed to load cart', err);
        return of(null); // Return null on other errors
      })
    ).subscribe(cart => {
      this.cartSubject.next(cart);
      this.loading = false;
    });
  }

  updateQuantity(item: CartItem, change: number): void {
    const newQuantity = item.quantity + change;
    if (newQuantity < 1) {
      this.removeItem(item.bookId);
      return;
    }

    this.http.patch<CartItem>(`http://localhost:3000/cart/items/${item.bookId}`, { quantity: newQuantity }).pipe(
      // After successful update, reload the cart to get the latest state
      switchMap(() => this.http.get<Cart>('http://localhost:3000/cart'))
    ).subscribe({
      next: (updatedCart) => {
        this.cartSubject.next(updatedCart);
        this.snackBar.open('Cart updated.', 'Close', { duration: 2000 });
      },
      error: (err) => this.handleError('Failed to update quantity', err),
    });
  }

  removeItem(bookId: number): void {
     if (!confirm('Remove this item from your cart?')) {
      return;
    }
    this.http.delete(`http://localhost:3000/cart/items/${bookId}`).pipe(
      // After successful delete, reload the cart
      switchMap(() => this.http.get<Cart>('http://localhost:3000/cart').pipe(
         catchError(err => {
           if (err.status === 404) return of(null); // Handle case where cart becomes empty
           throw err; // Rethrow other errors
         })
      ))
    ).subscribe({
      next: (updatedCart) => {
        this.cartSubject.next(updatedCart);
        this.snackBar.open('Item removed from cart.', 'Close', { duration: 2000 });
      },
      error: (err) => this.handleError('Failed to remove item', err),
    });
  }

   placeOrder(): void {
    if (!this.authService.isLoggedIn()) {
       this.snackBar.open('Please log in to place an order.', 'Close', { duration: 3000 });
       this.router.navigate(['/login']);
       return;
    }

    if (!this.shippingAddress.name || !this.shippingAddress.street || !this.shippingAddress.city || !this.shippingAddress.zip || !this.shippingAddress.country) {
      this.snackBar.open('Please fill in all shipping address fields.', 'Close', { duration: 3000 });
      return;
    }

    const cart = this.cartSubject.getValue();
    if (!cart || cart.items.length === 0) {
      this.snackBar.open('Your cart is empty.', 'Close', { duration: 3000 });
      return;
    }

    this.isPlacingOrder = true;
    this.error = null;

    // Prepare DTO matching backend expectations
    const orderDto = {
      items: cart.items.map(item => ({ bookId: item.bookId, quantity: item.quantity })),
      shippingAddress: this.shippingAddress
    };


    this.http.post('http://localhost:3000/orders', orderDto).subscribe({
      next: (order: any) => {
        this.snackBar.open(`Order #${order.orderNumber} placed successfully!`, 'Close', { duration: 5000 });
        this.cartSubject.next(null); // Clear local cart representation
        this.showCheckoutForm = false;
        this.isPlacingOrder = false;
        this.router.navigate(['/orders']); // Navigate to order history
      },
      error: (err) => {
        this.handleError('Failed to place order', err);
        this.isPlacingOrder = false;
      },
    });
  }


  private handleError(message: string, error: HttpErrorResponse): void {
    console.error(message, error);
    this.error = `${message}: ${error.error?.message || error.statusText}`;
    this.snackBar.open(this.error, 'Close', { duration: 5000 });
    this.loading = false; // Ensure loading stops on error
  }
}
