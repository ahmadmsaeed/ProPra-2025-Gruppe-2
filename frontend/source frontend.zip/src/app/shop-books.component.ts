import { Component, Input, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { ActivatedRoute } from '@angular/router';
import { Observable, of, BehaviorSubject, combineLatest } from 'rxjs'; // Import BehaviorSubject, combineLatest
import { catchError, map, startWith, debounceTime, distinctUntilChanged } from 'rxjs/operators'; // Import startWith, debounceTime, distinctUntilChanged
import { RouterModule } from '@angular/router';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AuthService } from './auth.service';
import { MatFormFieldModule } from '@angular/material/form-field'; // Import MatFormFieldModule
import { MatInputModule } from '@angular/material/input'; // Import MatInputModule
import { FormsModule } from '@angular/forms'; // Import FormsModule

interface Book {
  id: number;
  title: string;
  subtitle?: string;
  published: boolean;
  price: number; // Assuming price is available
}

interface Rating {
  id: number;
  value: number;
  user: { id: number; name: string };
  createdAt: string;
}

@Component({
  selector: 'app-shop-books',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatSnackBarModule,
    MatFormFieldModule, // Add
    MatInputModule,     // Add
    FormsModule         // Add
  ],
  templateUrl: './shop-books.component.html',
})
export class ShopBooksComponent implements OnInit {
  private allBooksSubject = new BehaviorSubject<Book[]>([]); // Holds all books for the shop
  allBooks$ = this.allBooksSubject.asObservable();
  filteredBooks$: Observable<Book[]> = of([]); // Books displayed after filtering

  private searchTermSubject = new BehaviorSubject<string>(''); // Holds the current search term
  searchTerm$ = this.searchTermSubject.asObservable();
  searchTerm: string = ''; // For ngModel binding

  shopId: number = 0;
  ratings: { [bookId: number]: Rating[] } = {};
  avgRatings: { [bookId: number]: number } = {};
  userRating: { [bookId: number]: number } = {};
  currentUserId: number | null = null;
  error: string | null = null;

  constructor(
    private http: HttpClient,
    private route: ActivatedRoute,
    private snackBar: MatSnackBar,
    private authService: AuthService
  ) {
    this.route.paramMap.subscribe(params => {
      this.shopId = Number(params.get('id'));
      this.loadBooks();
    });
  }

  ngOnInit() {
    const user = localStorage.getItem('user');
    if (user) {
      this.currentUserId = JSON.parse(user).id;
    }

    // Combine books and search term to create the filtered list
    this.filteredBooks$ = combineLatest([this.allBooks$, this.searchTerm$.pipe(startWith(''), debounceTime(300), distinctUntilChanged())]).pipe(
      map(([books, term]) => {
        if (!term) {
          return books; // No term? Return all books
        }
        const lowerTerm = term.toLowerCase();
        return books.filter(book =>
          book.title.toLowerCase().includes(lowerTerm) ||
          (book.subtitle && book.subtitle.toLowerCase().includes(lowerTerm))
        );
      })
    );
  }

  loadBooks(): void {
    this.http.get<Book[]>(`http://localhost:3000/shops/${this.shopId}/books`).pipe(
      map(books => books.sort((a, b) => a.title.localeCompare(b.title))), // Sort by title
      catchError((err: HttpErrorResponse) => {
        this.handleError('Failed to load books', err);
        return of([]);
      })
    ).subscribe(books => {
      this.allBooksSubject.next(books); // Update the source observable
    });
  }

  onSearchTermChange(term: string): void {
    this.searchTermSubject.next(term); // Update the search term observable
  }

  loadRatings(bookId: number) {
    // Add base URL
    this.http.get<Rating[]>(`http://localhost:3000/books/${bookId}/ratings`).subscribe(ratings => {
      this.ratings[bookId] = ratings;
      if (ratings.length > 0) {
        this.avgRatings[bookId] = ratings.reduce((a, b) => a + b.value, 0) / ratings.length;
        const my = ratings.find(r => r.user.id === this.currentUserId);
        this.userRating[bookId] = my ? my.value : 0;
      } else {
        this.avgRatings[bookId] = 0;
        this.userRating[bookId] = 0;
      }
    });
  }

  rateBook(bookId: number, value: number) {
    // Check if logged in before allowing rating
    if (!this.authService.isLoggedIn()) {
      this.snackBar.open('Please log in to rate books.', 'Close', { duration: 3000 });
      return;
    }
    // Add base URL
    this.http.post(`http://localhost:3000/ratings`, { bookId, value }).subscribe({
        next: () => this.loadRatings(bookId),
        error: (err) => this.handleError('Failed to submit rating', err)
    });
  }

  addToCart(bookId: number): void {
    // Check if logged in before allowing add to cart
    if (!this.authService.isLoggedIn()) {
      this.snackBar.open('Please log in to add items to your cart.', 'Close', { duration: 3000 });
      // Optionally redirect to login
      // import { Router } from '@angular/router';
      // private router: Router
      // this.router.navigate(['/login']);
      return;
    }

    // Add base URL
    this.http.post('http://localhost:3000/cart/items', { bookId, quantity: 1 }).subscribe({
      next: () => {
        this.snackBar.open('Book added to cart!', 'Close', { duration: 2000 });
      },
      error: (err: HttpErrorResponse) => {
        this.handleError('Failed to add item to cart', err);
      }
    });
  }

  private handleError(message: string, error: HttpErrorResponse): void {
    console.error(message, error);
    this.error = `${message}: ${error.error?.message || error.statusText}`;
    this.snackBar.open(this.error, 'Close', { duration: 5000 });
    // Consider how loading state should be handled on error if applicable
  }
}
