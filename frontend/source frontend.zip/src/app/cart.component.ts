import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { AuthService } from './auth.service';
import { Observable, BehaviorSubject, catchError, of, map, switchMap } from 'rxjs';

interface CartItem {
  id: number;
  quantity: number;
  bookId: number;
  book: {
    id: number;
    title: string;
    price: number;
  };
}

interface Cart {
  id: number;
  userId: number;
  items: CartItem[];
}

interface ShippingAddress {
  name: string;
  street: string;
  city: string;
  zip: string;
  country: string;
}

@Component({
  selector: 'app-cart',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatCardModule,
    MatListModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
    MatSnackBarModule,
  ],
  templateUrl: './cart.component.html',
})
export class CartComponent implements OnInit {
  private readonly cartUrl = 'http://localhost:3000/cart';

  private cartSubject = new BehaviorSubject<Cart | null>(null);
  cart$ = this.cartSubject.asObservable();
  totalAmount$: Observable<number> = of(0);

  loading = true;
  error: string | null = null;
  showCheckoutForm = false;
  shippingAddress: ShippingAddress = { name: '', street: '', city: '', zip: '', country: '' };
  isPlacingOrder = false;

  constructor(
    private http: HttpClient,
    private snackBar: MatSnackBar,
    private router: Router,
    public authService: AuthService
  ) {}

  ngOnInit(): void {
    this.loadCart();
    this.totalAmount$ = this.cart$.pipe(
      map(cart => cart?.items.reduce((sum, item) => sum + item.book.price * item.quantity, 0) ?? 0)
    );
  }

  loadCart(): void {
    this.loading = true;
    this.error = null;
    this.http.get<Cart>(`${this.cartUrl}`).pipe(
      catchError((err: HttpErrorResponse) => {
        if (err.status === 404) {
          return of(null);
        }
        this.handleError('Failed to load cart', err);
        return of(null);
      })
    ).subscribe(cart => {
      this.cartSubject.next(cart);
      this.loading = false;
    });
  }

  addToCart(bookId: number, quantity = 1): void {
    this.http.post<CartItem>(`${this.cartUrl}/add`, { bookId, quantity }).pipe(
      switchMap(() => this.http.get<Cart>(`${this.cartUrl}`))
    ).subscribe({
      next: updatedCart => {
        this.cartSubject.next(updatedCart);
        this.snackBar.open('Item added to cart.', 'Close', { duration: 2000 });
      },
      error: err => this.handleError('Failed to add item to cart', err)
    });
  }

  removeFromCart(bookId: number): void {
    if (!confirm('Remove this item from your cart?')) return;
    this.http.post<void>(`${this.cartUrl}/remove`, { bookId }).pipe(
      switchMap(() => this.http.get<Cart>(`${this.cartUrl}`))
    ).subscribe({
      next: updatedCart => {
        this.cartSubject.next(updatedCart);
        this.snackBar.open('Item removed from cart.', 'Close', { duration: 2000 });
      },
      error: err => this.handleError('Failed to remove item', err)
    });
  }

  clearCart(): void {
    this.http.delete<void>(`${this.cartUrl}/clear`).pipe(
      switchMap(() => this.http.get<Cart>(`${this.cartUrl}`))
    ).subscribe({
      next: emptyCart => {
        this.cartSubject.next(emptyCart);
        this.snackBar.open('Cart cleared.', 'Close', { duration: 2000 });
      },
      error: err => this.handleError('Failed to clear cart', err)
    });
  }

  placeOrder(): void {
    if (!this.authService.isLoggedIn()) {
      this.snackBar.open('Please log in to place an order.', 'Close', { duration: 3000 });
      this.router.navigate(['/login']);
      return;
    }

    if (!this.shippingAddress.name || !this.shippingAddress.street || !this.shippingAddress.city || !this.shippingAddress.zip || !this.shippingAddress.country) {
      this.snackBar.open('Please fill in all shipping address fields.', 'Close', { duration: 3000 });
      return;
    }

    const cart = this.cartSubject.getValue();
    if (!cart || cart.items.length === 0) {
      this.snackBar.open('Your cart is empty.', 'Close', { duration: 3000 });
      return;
    }

    this.isPlacingOrder = true;
    this.error = null;

    const orderDto = {
      items: cart.items.map(item => ({ bookId: item.bookId, quantity: item.quantity })),
      shippingAddress: this.shippingAddress
    };

    this.http.post('http://localhost:3000/orders', orderDto).subscribe({
      next: (order: any) => {
        this.snackBar.open(`Order #${order.orderNumber} placed successfully!`, 'Close', { duration: 5000 });
        this.cartSubject.next(null);
        this.showCheckoutForm = false;
        this.isPlacingOrder = false;
        this.router.navigate(['/orders']);
      },
      error: err => {
        this.handleError('Failed to place order', err);
        this.isPlacingOrder = false;
      }
    });
  }

  private handleError(message: string, error: HttpErrorResponse): void {
    console.error(message, error);
    this.error = `${message}: ${error.error?.message || error.statusText}`;
    this.snackBar.open(this.error, 'Close', { duration: 5000 });
    this.loading = false;
  }
}
