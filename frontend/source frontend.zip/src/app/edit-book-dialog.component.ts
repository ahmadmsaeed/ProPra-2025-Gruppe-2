\
// ... existing imports ...
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { HttpClient, HttpErrorResponse, HttpClientModule } from '@angular/common/http';
import { catchError } from 'rxjs/operators';
import { of, Observable } from 'rxjs';

// ... existing interface ...

@Component({
  // ... component decorator ...
})
export class EditBookDialogComponent implements OnInit {
  // ... existing properties ...

  constructor(
    public dialogRef: MatDialogRef<EditBookDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: { book?: Book, shopId?: number }
  ) {
    // ... existing constructor logic ...

    // Initialize form
    this.bookForm = this.fb.group({
      title: [data.book?.title ?? '', Validators.required],
      subtitle: [data.book?.subtitle ?? ''],
      isbn: [data.book?.isbn ?? '', [Validators.required, Validators.pattern(/^(?=(?:\D*\d){10}(?:(?:\D*\d){3})?$)[\d-]+$/)]],
      description: [data.book?.description ?? ''],
      price: [data.book?.price ?? null, [Validators.required, Validators.min(0)]],
      published: [data.book?.published ? new Date(data.book.published) : null]
    });
  }

  ngOnInit(): void {
    if (!this.shopId) {
       console.error("Shop ID fehlt!"); // Translated
       this.snackBar.open('Fehler: Shop ID fehlt.', 'Schließen', { duration: 5000 }); // Translated
       this.dialogRef.close();
    }
  }

  onCancel(): void {
    this.dialogRef.close();
  }

  onSave(): void {
    if (this.bookForm.invalid || !this.shopId) {
      this.snackBar.open('Bitte füllen Sie alle erforderlichen Felder korrekt aus.', 'Schließen', { duration: 3000 }); // Translated
      return;
    }

    // ... existing formData preparation ...

    let request$: Observable<Book | null>;
    let apiUrl = `http://localhost:3000/shops/${this.shopId}/books`;

    if (this.isEditMode && this.bookId) {
      apiUrl += `/${this.bookId}`;
      request$ = this.http.patch<Book>(apiUrl, formData);
    } else {
       this.snackBar.open('Funktion "Hinzufügen" in diesem Dialog noch nicht implementiert.', 'Schließen', { duration: 3000 }); // Translated
       return;
    }

    request$.pipe(
      catchError((err: HttpErrorResponse) => {
        console.error('Fehler beim Speichern des Buches:', err); // Translated
        this.snackBar.open(`Fehler beim Speichern des Buches: ${err.error?.message || err.statusText}`, 'Schließen', { duration: 5000 }); // Translated
        return of(null);
      })
    ).subscribe(response => {
      if (response) {
        this.snackBar.open(`Buch erfolgreich ${this.isEditMode ? 'aktualisiert' : 'hinzugefügt'}!`, 'Schließen', { duration: 3000 }); // Translated
        this.dialogRef.close('saved');
      }
    });
  }
}
