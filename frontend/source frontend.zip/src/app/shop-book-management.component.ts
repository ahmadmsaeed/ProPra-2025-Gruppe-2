\
// ... existing imports ...
import { Observable, of, catchError, switchMap, tap } from 'rxjs';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { EditBookDialogComponent } from '../edit-book-dialog/edit-book-dialog.component';
import { ReactiveFormsModule } from '@angular/forms';

// ... existing interfaces ...

@Component({
  // ... component decorator ...
})
export class ShopBookManagementComponent implements OnInit {
  // ... existing properties ...

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private snackBar: MatSnackBar,
    private dialog: MatDialog
  ) {}

  ngOnInit(): void {
    this.shop$ = this.route.paramMap.pipe(
      switchMap(params => {
        const id = params.get('shopId');
        if (!id) {
          this.error = 'Shop ID nicht in Route gefunden.'; // Translated
          this.loading = false;
          return of(null);
        }
        this.shopId = +id;
        // Placeholder for shop name - replace with actual fetch if needed
        return of({ id: this.shopId, name: `Shop ${this.shopId}` });
      }),
      tap(shop => {
        if (shop) {
          this.loadBooks(shop.id);
        }
      })
    );
  }

  loadBooks(shopId: number): void {
    this.loading = true;
    this.error = null;
    this.books$ = this.http.get<Book[]>(`http://localhost:3000/shops/${shopId}/books`).pipe(
      tap(() => this.loading = false),
      catchError(err => {
        this.handleError('Bücher konnten nicht geladen werden', err); // Translated
        this.loading = false;
        return of([]);
      })
    );
  }

  addBook(): void {
    // TODO: Implement Add Book Dialog opening
    this.snackBar.open('Funktion "Buch hinzufügen" noch nicht implementiert.', 'Schließen', { duration: 3000 }); // Translated
    console.log('Buch hinzufügen für Shop:', this.shopId);
  }

  editBook(book: Book): void {
    const dialogRef = this.dialog.open(EditBookDialogComponent, {
      width: '500px',
      data: { book: { ...book } }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'saved') {
        this.loadBooks(this.shopId!);
      }
    });
  }

  deleteBook(book: Book): void {
    if (!confirm(`Sind Sie sicher, dass Sie "${book.title}" löschen möchten?`)) { // Translated
      return;
    }

    this.http.delete(`http://localhost:3000/shops/${this.shopId}/books/${book.id}`).pipe(
      catchError(err => {
        this.handleError(`Fehler beim Löschen von Buch "${book.title}"`, err); // Translated
        return of(null);
      })
    ).subscribe(response => {
      if (response !== null) {
        this.snackBar.open(`Buch "${book.title}" erfolgreich gelöscht.`, 'Schließen', { duration: 3000 }); // Translated
        this.loadBooks(this.shopId!);
      }
    });
  }

  private handleError(message: string, error: HttpErrorResponse): void {
    console.error(message, error);
    const displayError = `${message}: ${error.error?.message || error.statusText || 'Unbekannter Fehler'}`; // Translated
    this.error = displayError;
    this.snackBar.open(displayError, 'Schließen', { duration: 5000 }); // Translated
  }
}
