import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { AuthService } from './auth.service'; // Corrected path
import { Observable, catchError, map, of, forkJoin } from 'rxjs';

interface User {
  id: number;
  email: string;
  name: string;
  role: string;
  isBlocked: boolean;
  createdAt: string;
  orders?: any[]; // Add orders if needed for customer display
}

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSnackBarModule,
  ],
  templateUrl: './admin-dashboard.component.html',
  // Add styles if needed: styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  merchants: User[] = [];
  customers: User[] = [];
  loading = true;
  error: string | null = null;

  merchantColumns: string[] = ['id', 'name', 'email', 'createdAt', 'isBlocked', 'actions'];
  customerColumns: string[] = ['id', 'name', 'email', 'createdAt', 'isBlocked', 'orderCount', 'actions']; // Added orderCount

  constructor(
    private http: HttpClient,
    public authService: AuthService, // Make public for template access
    private snackBar: MatSnackBar
  ) {}

  ngOnInit(): void {
    if (this.authService.isAdmin()) {
      this.loadData();
    } else {
      this.error = "Access Denied.";
      this.loading = false;
    }
  }

  loadData(): void {
    this.loading = true;
    this.error = null;

    const merchantsRequest = this.http.get<User[]>('http://localhost:3000/admin/merchants').pipe(
      catchError(err => {
        this.handleError('Failed to load merchants', err);
        return of([]); // Return empty array on error
      })
    );

    const customersRequest = this.http.get<User[]>('http://localhost:3000/admin/customers').pipe(
      map(customers => customers.map(c => ({ ...c, orderCount: c.orders?.length ?? 0 }))), // Calculate order count
      catchError(err => {
        this.handleError('Failed to load customers', err);
        return of([]); // Return empty array on error
      })
    );

    forkJoin({ merchants: merchantsRequest, customers: customersRequest }).subscribe({
      next: ({ merchants, customers }) => {
        this.merchants = merchants;
        this.customers = customers;
        this.loading = false;
      },
      // Errors are caught individually in pipes, forkJoin completes even if one fails
      complete: () => {
        this.loading = false; // Ensure loading is false even if requests error out
      }
    });
  }

  blockUser(userId: number): void {
    this.http.patch<User>(`http://localhost:3000/admin/users/${userId}/block`, {}).subscribe({
      next: () => {
        this.snackBar.open('User blocked successfully.', 'Close', { duration: 3000 });
        this.refreshUserData(userId, true); // Refresh UI
      },
      error: (err) => this.handleError('Failed to block user', err),
    });
  }

  unblockUser(userId: number): void {
    this.http.patch<User>(`http://localhost:3000/admin/users/${userId}/unblock`, {}).subscribe({
      next: () => {
        this.snackBar.open('User unblocked successfully.', 'Close', { duration: 3000 });
        this.refreshUserData(userId, false); // Refresh UI
      },
      error: (err) => this.handleError('Failed to unblock user', err),
    });
  }

  private refreshUserData(userId: number, isBlocked: boolean): void {
    // Optimistic UI update: Update the local data without reloading everything
    this.merchants = this.merchants.map(u => u.id === userId ? { ...u, isBlocked } : u);
    this.customers = this.customers.map(u => u.id === userId ? { ...u, isBlocked } : u);
    // Alternatively, call this.loadData() for a full refresh
  }

  private handleError(message: string, error: HttpErrorResponse): void {
    console.error(message, error);
    this.error = `${message}: ${error.error?.message || error.statusText}`;
    this.snackBar.open(this.error, 'Close', { duration: 5000 });
    this.loading = false; // Ensure loading stops on error
  }
}
