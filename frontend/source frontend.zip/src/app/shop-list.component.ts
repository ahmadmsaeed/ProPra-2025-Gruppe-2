import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { HttpClient, HttpErrorResponse } from '@angular/common/http'; // Added HttpErrorResponse
import { Observable, of, BehaviorSubject, catchError, debounceTime, distinctUntilChanged, filter, switchMap, tap } from 'rxjs'; // Added operators
import { MatCardModule } from '@angular/material/card'; // Ensure MatCardModule is imported
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list'; // Add MatListModule
import { MatIconModule } from '@angular/material/icon'; // Add MatIconModule
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar'; // Add SnackBar
import { MatButtonModule } from '@angular/material/button'; // Ensure MatButtonModule is imported

interface Shop {
  id: number;
  name: string;
  location: string;
}

// Add Book interface if not already present globally
interface Book {
  id: number;
  title: string;
  subtitle: string;
  price: number;
  // Add other fields if needed
}

@Component({
  selector: 'app-shop-list',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatCardModule, // Ensure MatCardModule is imported
    MatFormFieldModule, // Add
    MatInputModule, // Add
    MatListModule, // Add
    MatIconModule, // Add
    MatSnackBarModule, // Add
    MatButtonModule // Ensure MatButtonModule is imported
  ],
  templateUrl: './shop-list.component.html',
})
export class ShopListComponent {
  shops$: Observable<Shop[]>;
  // Add search related properties
  private searchTerms = new BehaviorSubject<string>('');
  searchResults$: Observable<Book[]> = of([]);
  searchLoading = false;
  searchError: string | null = null;
  searched = false; // Flag to know if a search has been attempted

  constructor(
    private http: HttpClient,
    private snackBar: MatSnackBar // Inject SnackBar
    ) {
    this.shops$ = this.http.get<Shop[]>('http://localhost:3000/shops');

    // Setup search observable stream
    this.searchResults$ = this.searchTerms.pipe(
      filter(term => term.length > 2 || term.length === 0), // Search only if term > 2 chars or empty (to clear)
      debounceTime(300), // Wait for 300ms pause in events
      distinctUntilChanged(), // Ignore if next search term is same as previous
      tap(term => {
        this.searchLoading = term.length > 0; // Show loading only if term is not empty
        this.searchError = null;
        this.searched = term.length > 0; // Mark that a search was attempted
        if (term.length === 0) {
          this.searchLoading = false; // Stop loading if term is cleared
        }
      }),
      switchMap(term => {
        if (term.length === 0) {
          return of([]); // Clear results if search term is empty
        }
        // *** IMPORTANT: Update backend URL when search endpoint exists ***
        return this.http.get<Book[]>(`http://localhost:3000/books?search=${term}`).pipe(
          catchError((err: HttpErrorResponse) => { // Specify HttpErrorResponse type
            console.error('Book search failed', err);
            this.searchError = 'Failed to search books. Backend might not support search yet.';
            return of([]); // Return empty array on error
          })
        );
      }),
      tap(() => this.searchLoading = false) // Stop loading after results/error
    );
  }

  searchBooks(term: string): void {
    this.searchTerms.next(term.trim());
  }

  // Add to cart functionality (basic example)
  addToCart(bookId: number): void {
    this.http.post('http://localhost:3000/cart/items', { bookId, quantity: 1 }).subscribe({
      next: () => {
        this.snackBar.open('Book added to cart!', 'Close', { duration: 2000 });
      },
      error: (err: HttpErrorResponse) => { // Specify HttpErrorResponse type
         console.error('Failed to add to cart', err);
         // Check for 401 Unauthorized
         if (err.status === 401) {
            this.snackBar.open('Please log in to add items to your cart.', 'Close', { duration: 3000 });
            // Optionally redirect to login: this.router.navigate(['/login']);
         } else {
            this.snackBar.open(`Error adding to cart: ${err.error?.message || 'Please try again.'}`, 'Close', { duration: 3000 });
         }
      }
    });
  }
}
