import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { HttpClient, HttpErrorResponse, HttpClientModule } from '@angular/common/http';
import { MatTableModule } from '@angular/material/table';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { Observable, of, catchError, switchMap, tap } from 'rxjs';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { EditBookDialogComponent } from '../edit-book-dialog/edit-book-dialog.component';
import { ReactiveFormsModule } from '@angular/forms';

interface Book {
  id: number;
  title: string;
  author: string;
  price: number;
  shopId: number;
}

interface Shop {
  id: number;
  name: string;
  location: string;
}

@Component({
  selector: 'app-shop-book-management',
  standalone: true,
  imports: [
    CommonModule,
    RouterLink,
    HttpClientModule,
    MatTableModule,
    MatButtonModule,
    MatIconModule,
    MatCardModule,
    MatSnackBarModule,
    MatProgressSpinnerModule,
    MatDialogModule,
    ReactiveFormsModule,
    EditBookDialogComponent
  ],
  templateUrl: './shop-book-management.component.html',
  styleUrls: ['./shop-book-management.component.scss']
})
export class ShopBookManagementComponent implements OnInit {
  private route = inject(ActivatedRoute);
  private http = inject(HttpClient);
  private snackBar = inject(MatSnackBar);
  private dialog = inject(MatDialog);

  shopId: number | null = null;
  shop$: Observable<Shop | null> = of(null);
  books$: Observable<Book[]> = of([]);
  loading = true;
  error: string | null = null;

  displayedColumns: string[] = ['title', 'author', 'price', 'actions'];

  constructor() {}

  ngOnInit(): void {
    this.route.paramMap.subscribe(params => {
      const shopId = params.get('id');
      if (shopId) {
        this.shopId = +shopId;
        this.loadBooks(this.shopId);
      }
    });
  }

  loadBooks(shopId: number): void {
    this.http.get<Book[]>(`/api/shops/${shopId}/books`).subscribe({
      next: (data) => {
        this.books$ = of(data);
        this.loading = false;
      },
      error: (error) => this.handleError(error)
    });
  }

  addBook(): void {
    this.snackBar.open('Add book functionality not yet implemented.', 'Close', { duration: 3000 });
    console.log('Add book for shop:', this.shopId);
  }

  editBook(book: Book): void {
    const dialogRef = this.dialog.open(EditBookDialogComponent, {
      width: '500px',
      data: { book: { ...book } }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result === 'saved') {
        this.loadBooks(this.shopId!);
      }
    });
  }

  deleteBook(bookId: number): void {
    // ... existing delete logic ...
  }

  private handleError(error: HttpErrorResponse) {
    // ... existing error handling logic ...
  }
}
