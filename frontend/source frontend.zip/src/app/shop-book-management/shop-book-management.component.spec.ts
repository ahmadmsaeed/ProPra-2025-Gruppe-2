import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ShopBookManagementComponent } from './shop-book-management.component';

describe('ShopBookManagementComponent', () => {
  let component: ShopBookManagementComponent;
  let fixture: ComponentFixture<ShopBookManagementComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [ShopBookManagementComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ShopBookManagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
