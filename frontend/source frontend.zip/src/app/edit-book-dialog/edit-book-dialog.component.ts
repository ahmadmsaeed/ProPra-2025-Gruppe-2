import { Component } from '@angular/core';

@Component({
  selector: 'app-edit-book-dialog',
  standalone: true,
  imports: [],
  templateUrl: './edit-book-dialog.component.html',
  styleUrl: './edit-book-dialog.component.scss'
})
export class EditBookDialogComponent {

}
