import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { MatCardModule } from '@angular/material/card';
import { MatListModule } from '@angular/material/list';
import { AuthService } from './auth.service';
import { Observable, catchError, of } from 'rxjs';

interface SalesStats {
  salesPerBook: { bookId: number; title: string; revenue: number; quantity: number }[];
  salesPerDay: { date: string; revenue: number }[];
}

@Component({
  selector: 'app-merchant-dashboard',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatListModule],
  templateUrl: './merchant-dashboard.component.html',
})
export class MerchantDashboardComponent implements OnInit {
  stats$: Observable<SalesStats | null> = of(null);
  loading = true;
  error: string | null = null;

  constructor(private http: HttpClient, public authService: AuthService) {}

  ngOnInit(): void {
    if (this.authService.isMerchant()) {
      this.loadStats();
    } else {
      this.error = "Access Denied.";
      this.loading = false;
    }
  }

  loadStats(): void {
    this.loading = true;
    this.error = null;
    this.stats$ = this.http.get<SalesStats>('http://localhost:3000/auth/merchant/stats').pipe(
      catchError((err: HttpErrorResponse) => {
        console.error('Failed to load merchant stats', err);
        this.error = `Failed to load stats: ${err.error?.message || err.statusText}`;
        this.loading = false;
        return of(null); // Return null on error
      }),
      // tap(() => this.loading = false) // Handled in subscribe/catchError
    );
    // Need to subscribe to trigger loading=false after stream completes/errors
    this.stats$.subscribe(() => this.loading = false);
  }
}
