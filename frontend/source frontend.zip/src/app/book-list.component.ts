\
// ... existing imports ...
import { CartService } from './cart.service'; // Import CartService
import { MatSnackBar } from '@angular/material/snack-bar';
// ... other imports ...

@Component({
  // ... component decorator ...
})
export class BookListComponent implements OnInit {
  // ... existing properties ...
  isAddingToCart: { [bookId: number]: boolean } = {}; // Track adding status per book

  constructor(
    private route: ActivatedRoute,
    private http: HttpClient,
    private cartService: CartService, // Inject CartService
    private snackBar: MatSnackBar // Inject MatSnackBar
  ) {}

  // ... existing ngOnInit, loadShopDetails, loadBooks ...

  addToCart(book: Book): void {
    if (this.isAddingToCart[book.id]) return; // Prevent multiple clicks

    this.isAddingToCart[book.id] = true; // Set loading state for this button
    this.cartService.addToCart(book.id, 1).subscribe({ // Add one item
      next: () => {
        this.snackBar.open(`"${book.title}" zum Warenkorb hinzugefügt.`, 'Schließen', { duration: 3000 }); // Translated
        this.isAddingToCart[book.id] = false; // Reset loading state
      },
      error: (err) => {
        this.handleError('Fehler beim Hinzufügen zum Warenkorb', err); // Translated
        this.isAddingToCart[book.id] = false; // Reset loading state
      }
    });
  }

  rateBook(book: Book): void {
    // Placeholder for rating functionality
    this.snackBar.open(`Bewertungsfunktion für "${book.title}" noch nicht implementiert.`, 'Schließen', { duration: 3000 }); // Translated
  }

  private handleError(message: string, error: HttpErrorResponse): void {
    console.error(message, error);
    const displayError = `${message}: ${error.error?.message || error.statusText || 'Unbekannter Fehler'}`; // Translated
    this.error = displayError;
    this.snackBar.open(displayError, 'Schließen', { duration: 5000 }); // Translated
    this.loading = false; // Ensure loading stops on error
  }
}
